-- MariaDB dump 10.17  Distrib 10.4.11-MariaDB, for osx10.15 (x86_64)
--
-- Host: 0.0.0.0    Database: pretix
-- ------------------------------------------------------
-- Server version	10.3.22-MariaDB-1:10.3.22+maria~bionic

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=333 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add permission',1,'add_permission'),(2,'Can change permission',1,'change_permission'),(3,'Can delete permission',1,'delete_permission'),(4,'Can view permission',1,'view_permission'),(5,'Can add group',2,'add_group'),(6,'Can change group',2,'change_group'),(7,'Can delete group',2,'delete_group'),(8,'Can view group',2,'view_group'),(9,'Can add content type',3,'add_contenttype'),(10,'Can change content type',3,'change_contenttype'),(11,'Can delete content type',3,'delete_contenttype'),(12,'Can view content type',3,'view_contenttype'),(13,'Can add session',4,'add_session'),(14,'Can change session',4,'change_session'),(15,'Can delete session',4,'delete_session'),(16,'Can view session',4,'view_session'),(17,'Can add User',5,'add_user'),(18,'Can change User',5,'change_user'),(19,'Can delete User',5,'delete_user'),(20,'Can view User',5,'view_user'),(21,'Can add cached file',6,'add_cachedfile'),(22,'Can change cached file',6,'change_cachedfile'),(23,'Can delete cached file',6,'delete_cachedfile'),(24,'Can view cached file',6,'view_cachedfile'),(25,'Can add cached ticket',7,'add_cachedticket'),(26,'Can change cached ticket',7,'change_cachedticket'),(27,'Can delete cached ticket',7,'delete_cachedticket'),(28,'Can view cached ticket',7,'view_cachedticket'),(29,'Can add Cart position',8,'add_cartposition'),(30,'Can change Cart position',8,'change_cartposition'),(31,'Can delete Cart position',8,'delete_cartposition'),(32,'Can view Cart position',8,'view_cartposition'),(33,'Can add Event',9,'add_event'),(34,'Can change Event',9,'change_event'),(35,'Can delete Event',9,'delete_event'),(36,'Can view Event',9,'view_event'),(37,'Can add event lock',10,'add_eventlock'),(38,'Can change event lock',10,'change_eventlock'),(39,'Can delete event lock',10,'delete_eventlock'),(40,'Can view event lock',10,'view_eventlock'),(41,'Can add Product',11,'add_item'),(42,'Can change Product',11,'change_item'),(43,'Can delete Product',11,'delete_item'),(44,'Can view Product',11,'view_item'),(45,'Can add Product category',12,'add_itemcategory'),(46,'Can change Product category',12,'change_itemcategory'),(47,'Can delete Product category',12,'delete_itemcategory'),(48,'Can view Product category',12,'view_itemcategory'),(49,'Can add Product variation',13,'add_itemvariation'),(50,'Can change Product variation',13,'change_itemvariation'),(51,'Can delete Product variation',13,'delete_itemvariation'),(52,'Can view Product variation',13,'view_itemvariation'),(53,'Can add log entry',14,'add_logentry'),(54,'Can change log entry',14,'change_logentry'),(55,'Can delete log entry',14,'delete_logentry'),(56,'Can view log entry',14,'view_logentry'),(57,'Can add Order',15,'add_order'),(58,'Can change Order',15,'change_order'),(59,'Can delete Order',15,'delete_order'),(60,'Can view Order',15,'view_order'),(61,'Can add Order position',16,'add_orderposition'),(62,'Can change Order position',16,'change_orderposition'),(63,'Can delete Order position',16,'delete_orderposition'),(64,'Can view Order position',16,'view_orderposition'),(65,'Can add Organizer',17,'add_organizer'),(66,'Can change Organizer',17,'change_organizer'),(67,'Can delete Organizer',17,'delete_organizer'),(68,'Can view Organizer',17,'view_organizer'),(69,'Can add Question',18,'add_question'),(70,'Can change Question',18,'change_question'),(71,'Can delete Question',18,'delete_question'),(72,'Can view Question',18,'view_question'),(73,'Can add question answer',19,'add_questionanswer'),(74,'Can change question answer',19,'change_questionanswer'),(75,'Can delete question answer',19,'delete_questionanswer'),(76,'Can view question answer',19,'view_questionanswer'),(77,'Can add Quota',20,'add_quota'),(78,'Can change Quota',20,'change_quota'),(79,'Can delete Quota',20,'delete_quota'),(80,'Can view Quota',20,'view_quota'),(81,'Can add Voucher',21,'add_voucher'),(82,'Can change Voucher',21,'change_voucher'),(83,'Can delete Voucher',21,'delete_voucher'),(84,'Can view Voucher',21,'view_voucher'),(85,'Can add invoice address',22,'add_invoiceaddress'),(86,'Can change invoice address',22,'change_invoiceaddress'),(87,'Can delete invoice address',22,'delete_invoiceaddress'),(88,'Can view invoice address',22,'view_invoiceaddress'),(89,'Can add invoice',23,'add_invoice'),(90,'Can change invoice',23,'change_invoice'),(91,'Can delete invoice',23,'delete_invoice'),(92,'Can view invoice',23,'view_invoice'),(93,'Can add invoice line',24,'add_invoiceline'),(94,'Can change invoice line',24,'change_invoiceline'),(95,'Can delete invoice line',24,'delete_invoiceline'),(96,'Can view invoice line',24,'view_invoiceline'),(97,'Can add Question option',25,'add_questionoption'),(98,'Can change Question option',25,'change_questionoption'),(99,'Can delete Question option',25,'delete_questionoption'),(100,'Can view Question option',25,'view_questionoption'),(101,'Can add u2f device',26,'add_u2fdevice'),(102,'Can change u2f device',26,'change_u2fdevice'),(103,'Can delete u2f device',26,'delete_u2fdevice'),(104,'Can view u2f device',26,'view_u2fdevice'),(105,'Can add checkin',27,'add_checkin'),(106,'Can change checkin',27,'change_checkin'),(107,'Can delete checkin',27,'delete_checkin'),(108,'Can view checkin',27,'view_checkin'),(109,'Can add required action',28,'add_requiredaction'),(110,'Can change required action',28,'change_requiredaction'),(111,'Can delete required action',28,'delete_requiredaction'),(112,'Can view required action',28,'view_requiredaction'),(113,'Can add cached combined ticket',29,'add_cachedcombinedticket'),(114,'Can change cached combined ticket',29,'change_cachedcombinedticket'),(115,'Can delete cached combined ticket',29,'delete_cachedcombinedticket'),(116,'Can view cached combined ticket',29,'view_cachedcombinedticket'),(117,'Can add Waiting list entry',30,'add_waitinglistentry'),(118,'Can change Waiting list entry',30,'change_waitinglistentry'),(119,'Can delete Waiting list entry',30,'delete_waitinglistentry'),(120,'Can view Waiting list entry',30,'view_waitinglistentry'),(121,'Can add event_ settings store',31,'add_event_settingsstore'),(122,'Can change event_ settings store',31,'change_event_settingsstore'),(123,'Can delete event_ settings store',31,'delete_event_settingsstore'),(124,'Can view event_ settings store',31,'view_event_settingsstore'),(125,'Can add organizer_ settings store',32,'add_organizer_settingsstore'),(126,'Can change organizer_ settings store',32,'change_organizer_settingsstore'),(127,'Can delete organizer_ settings store',32,'delete_organizer_settingsstore'),(128,'Can view organizer_ settings store',32,'view_organizer_settingsstore'),(129,'Can add global settings object_ settings store',33,'add_globalsettingsobject_settingsstore'),(130,'Can change global settings object_ settings store',33,'change_globalsettingsobject_settingsstore'),(131,'Can delete global settings object_ settings store',33,'delete_globalsettingsobject_settingsstore'),(132,'Can view global settings object_ settings store',33,'view_globalsettingsobject_settingsstore'),(133,'Can add item add on',34,'add_itemaddon'),(134,'Can change item add on',34,'change_itemaddon'),(135,'Can delete item add on',34,'delete_itemaddon'),(136,'Can view item add on',34,'view_itemaddon'),(137,'Can add Team',35,'add_team'),(138,'Can change Team',35,'change_team'),(139,'Can delete Team',35,'delete_team'),(140,'Can view Team',35,'view_team'),(141,'Can add team invite',36,'add_teaminvite'),(142,'Can change team invite',36,'change_teaminvite'),(143,'Can delete team invite',36,'delete_teaminvite'),(144,'Can view team invite',36,'view_teaminvite'),(145,'Can add team api token',37,'add_teamapitoken'),(146,'Can change team api token',37,'change_teamapitoken'),(147,'Can delete team api token',37,'delete_teamapitoken'),(148,'Can view team api token',37,'view_teamapitoken'),(149,'Can add Date in event series',38,'add_subevent'),(150,'Can change Date in event series',38,'change_subevent'),(151,'Can delete Date in event series',38,'delete_subevent'),(152,'Can view Date in event series',38,'view_subevent'),(153,'Can add sub event item',39,'add_subeventitem'),(154,'Can change sub event item',39,'change_subeventitem'),(155,'Can delete sub event item',39,'delete_subeventitem'),(156,'Can view sub event item',39,'view_subeventitem'),(157,'Can add sub event item variation',40,'add_subeventitemvariation'),(158,'Can change sub event item variation',40,'change_subeventitemvariation'),(159,'Can delete sub event item variation',40,'delete_subeventitemvariation'),(160,'Can view sub event item variation',40,'view_subeventitemvariation'),(161,'Can add tax rule',41,'add_taxrule'),(162,'Can change tax rule',41,'change_taxrule'),(163,'Can delete tax rule',41,'delete_taxrule'),(164,'Can view tax rule',41,'view_taxrule'),(165,'Can add event meta property',42,'add_eventmetaproperty'),(166,'Can change event meta property',42,'change_eventmetaproperty'),(167,'Can delete event meta property',42,'delete_eventmetaproperty'),(168,'Can view event meta property',42,'view_eventmetaproperty'),(169,'Can add event meta value',43,'add_eventmetavalue'),(170,'Can change event meta value',43,'change_eventmetavalue'),(171,'Can delete event meta value',43,'delete_eventmetavalue'),(172,'Can view event meta value',43,'view_eventmetavalue'),(173,'Can add sub event meta value',44,'add_subeventmetavalue'),(174,'Can change sub event meta value',44,'change_subeventmetavalue'),(175,'Can delete sub event meta value',44,'delete_subeventmetavalue'),(176,'Can view sub event meta value',44,'view_subeventmetavalue'),(177,'Can add order fee',45,'add_orderfee'),(178,'Can change order fee',45,'change_orderfee'),(179,'Can delete order fee',45,'delete_orderfee'),(180,'Can view order fee',45,'view_orderfee'),(181,'Can add checkin list',46,'add_checkinlist'),(182,'Can change checkin list',46,'change_checkinlist'),(183,'Can delete checkin list',46,'delete_checkinlist'),(184,'Can view checkin list',46,'view_checkinlist'),(185,'Can add notification setting',47,'add_notificationsetting'),(186,'Can change notification setting',47,'change_notificationsetting'),(187,'Can delete notification setting',47,'delete_notificationsetting'),(188,'Can view notification setting',47,'view_notificationsetting'),(189,'Can add staff session',48,'add_staffsession'),(190,'Can change staff session',48,'change_staffsession'),(191,'Can delete staff session',48,'delete_staffsession'),(192,'Can view staff session',48,'view_staffsession'),(193,'Can add staff session audit log',49,'add_staffsessionauditlog'),(194,'Can change staff session audit log',49,'change_staffsessionauditlog'),(195,'Can delete staff session audit log',49,'delete_staffsessionauditlog'),(196,'Can view staff session audit log',49,'view_staffsessionauditlog'),(197,'Can add order payment',50,'add_orderpayment'),(198,'Can change order payment',50,'change_orderpayment'),(199,'Can delete order payment',50,'delete_orderpayment'),(200,'Can view order payment',50,'view_orderpayment'),(201,'Can add order refund',51,'add_orderrefund'),(202,'Can change order refund',51,'change_orderrefund'),(203,'Can delete order refund',51,'delete_orderrefund'),(204,'Can view order refund',51,'view_orderrefund'),(205,'Can add device',52,'add_device'),(206,'Can change device',52,'change_device'),(207,'Can delete device',52,'delete_device'),(208,'Can view device',52,'view_device'),(209,'Can add item bundle',53,'add_itembundle'),(210,'Can change item bundle',53,'change_itembundle'),(211,'Can delete item bundle',53,'delete_itembundle'),(212,'Can view item bundle',53,'view_itembundle'),(213,'Can add seating plan',54,'add_seatingplan'),(214,'Can change seating plan',54,'change_seatingplan'),(215,'Can delete seating plan',54,'delete_seatingplan'),(216,'Can view seating plan',54,'view_seatingplan'),(217,'Can add seat category mapping',55,'add_seatcategorymapping'),(218,'Can change seat category mapping',55,'change_seatcategorymapping'),(219,'Can delete seat category mapping',55,'delete_seatcategorymapping'),(220,'Can view seat category mapping',55,'view_seatcategorymapping'),(221,'Can add seat',56,'add_seat'),(222,'Can change seat',56,'change_seat'),(223,'Can delete seat',56,'delete_seat'),(224,'Can view seat',56,'view_seat'),(225,'Can add web authn device',57,'add_webauthndevice'),(226,'Can change web authn device',57,'change_webauthndevice'),(227,'Can delete web authn device',57,'delete_webauthndevice'),(228,'Can view web authn device',57,'view_webauthndevice'),(229,'Can add gift card',58,'add_giftcard'),(230,'Can change gift card',58,'change_giftcard'),(231,'Can delete gift card',58,'delete_giftcard'),(232,'Can view gift card',58,'view_giftcard'),(233,'Can add gift card transaction',59,'add_giftcardtransaction'),(234,'Can change gift card transaction',59,'change_giftcardtransaction'),(235,'Can delete gift card transaction',59,'delete_giftcardtransaction'),(236,'Can view gift card transaction',59,'view_giftcardtransaction'),(237,'Can add gift card acceptance',60,'add_giftcardacceptance'),(238,'Can change gift card acceptance',60,'change_giftcardacceptance'),(239,'Can delete gift card acceptance',60,'delete_giftcardacceptance'),(240,'Can view gift card acceptance',60,'view_giftcardacceptance'),(241,'Can add Known domain',61,'add_knowndomain'),(242,'Can change Known domain',61,'change_knowndomain'),(243,'Can delete Known domain',61,'delete_knowndomain'),(244,'Can view Known domain',61,'view_knowndomain'),(245,'Can add o auth access token',62,'add_oauthaccesstoken'),(246,'Can change o auth access token',62,'change_oauthaccesstoken'),(247,'Can delete o auth access token',62,'delete_oauthaccesstoken'),(248,'Can view o auth access token',62,'view_oauthaccesstoken'),(249,'Can add o auth application',63,'add_oauthapplication'),(250,'Can change o auth application',63,'change_oauthapplication'),(251,'Can delete o auth application',63,'delete_oauthapplication'),(252,'Can view o auth application',63,'view_oauthapplication'),(253,'Can add o auth grant',64,'add_oauthgrant'),(254,'Can change o auth grant',64,'change_oauthgrant'),(255,'Can delete o auth grant',64,'delete_oauthgrant'),(256,'Can view o auth grant',64,'view_oauthgrant'),(257,'Can add o auth refresh token',65,'add_oauthrefreshtoken'),(258,'Can change o auth refresh token',65,'change_oauthrefreshtoken'),(259,'Can delete o auth refresh token',65,'delete_oauthrefreshtoken'),(260,'Can view o auth refresh token',65,'view_oauthrefreshtoken'),(261,'Can add web hook',66,'add_webhook'),(262,'Can change web hook',66,'change_webhook'),(263,'Can delete web hook',66,'delete_webhook'),(264,'Can view web hook',66,'view_webhook'),(265,'Can add web hook call',67,'add_webhookcall'),(266,'Can change web hook call',67,'change_webhookcall'),(267,'Can delete web hook call',67,'delete_webhookcall'),(268,'Can view web hook call',67,'view_webhookcall'),(269,'Can add web hook event listener',68,'add_webhookeventlistener'),(270,'Can change web hook event listener',68,'change_webhookeventlistener'),(271,'Can delete web hook event listener',68,'delete_webhookeventlistener'),(272,'Can view web hook event listener',68,'view_webhookeventlistener'),(273,'Can add api call',69,'add_apicall'),(274,'Can change api call',69,'change_apicall'),(275,'Can delete api call',69,'delete_apicall'),(276,'Can view api call',69,'view_apicall'),(277,'Can add thumbnail',70,'add_thumbnail'),(278,'Can change thumbnail',70,'change_thumbnail'),(279,'Can delete thumbnail',70,'delete_thumbnail'),(280,'Can view thumbnail',70,'view_thumbnail'),(281,'Can add bank import job',71,'add_bankimportjob'),(282,'Can change bank import job',71,'change_bankimportjob'),(283,'Can delete bank import job',71,'delete_bankimportjob'),(284,'Can view bank import job',71,'view_bankimportjob'),(285,'Can add bank transaction',72,'add_banktransaction'),(286,'Can change bank transaction',72,'change_banktransaction'),(287,'Can delete bank transaction',72,'delete_banktransaction'),(288,'Can view bank transaction',72,'view_banktransaction'),(289,'Can add referenced stripe object',73,'add_referencedstripeobject'),(290,'Can change referenced stripe object',73,'change_referencedstripeobject'),(291,'Can delete referenced stripe object',73,'delete_referencedstripeobject'),(292,'Can view referenced stripe object',73,'view_referencedstripeobject'),(293,'Can add registered apple pay domain',74,'add_registeredapplepaydomain'),(294,'Can change registered apple pay domain',74,'change_registeredapplepaydomain'),(295,'Can delete registered apple pay domain',74,'delete_registeredapplepaydomain'),(296,'Can view registered apple pay domain',74,'view_registeredapplepaydomain'),(297,'Can add referenced pay pal object',75,'add_referencedpaypalobject'),(298,'Can change referenced pay pal object',75,'change_referencedpaypalobject'),(299,'Can delete referenced pay pal object',75,'delete_referencedpaypalobject'),(300,'Can view referenced pay pal object',75,'view_referencedpaypalobject'),(301,'Can add ticket layout',76,'add_ticketlayout'),(302,'Can change ticket layout',76,'change_ticketlayout'),(303,'Can delete ticket layout',76,'delete_ticketlayout'),(304,'Can view ticket layout',76,'view_ticketlayout'),(305,'Can add ticket layout item',77,'add_ticketlayoutitem'),(306,'Can change ticket layout item',77,'change_ticketlayoutitem'),(307,'Can delete ticket layout item',77,'delete_ticketlayoutitem'),(308,'Can view ticket layout item',77,'view_ticketlayoutitem'),(309,'Can add app configuration',78,'add_appconfiguration'),(310,'Can change app configuration',78,'change_appconfiguration'),(311,'Can delete app configuration',78,'delete_appconfiguration'),(312,'Can view app configuration',78,'view_appconfiguration'),(313,'Can add badge item',79,'add_badgeitem'),(314,'Can change badge item',79,'change_badgeitem'),(315,'Can delete badge item',79,'delete_badgeitem'),(316,'Can view badge item',79,'view_badgeitem'),(317,'Can add badge layout',80,'add_badgelayout'),(318,'Can change badge layout',80,'change_badgelayout'),(319,'Can delete badge layout',80,'delete_badgelayout'),(320,'Can view badge layout',80,'view_badgelayout'),(321,'Can add TOTP device',81,'add_totpdevice'),(322,'Can change TOTP device',81,'change_totpdevice'),(323,'Can delete TOTP device',81,'delete_totpdevice'),(324,'Can view TOTP device',81,'view_totpdevice'),(325,'Can add static device',82,'add_staticdevice'),(326,'Can change static device',82,'change_staticdevice'),(327,'Can delete static device',82,'delete_staticdevice'),(328,'Can view static device',82,'view_staticdevice'),(329,'Can add static token',83,'add_statictoken'),(330,'Can change static token',83,'change_statictoken'),(331,'Can delete static token',83,'delete_statictoken'),(332,'Can view static token',83,'view_statictoken');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `badges_badgeitem`
--

DROP TABLE IF EXISTS `badges_badgeitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `badges_badgeitem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) DEFAULT NULL,
  `layout_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_id` (`item_id`),
  KEY `badges_badgeitem_layout_id_e98e19ee_fk_badges_badgelayout_id` (`layout_id`),
  CONSTRAINT `badges_badgeitem_item_id_f10e9e2b_fk_pretixbase_item_id` FOREIGN KEY (`item_id`) REFERENCES `pretixbase_item` (`id`),
  CONSTRAINT `badges_badgeitem_layout_id_e98e19ee_fk_badges_badgelayout_id` FOREIGN KEY (`layout_id`) REFERENCES `badges_badgelayout` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badges_badgeitem`
--

LOCK TABLES `badges_badgeitem` WRITE;
/*!40000 ALTER TABLE `badges_badgeitem` DISABLE KEYS */;
/*!40000 ALTER TABLE `badges_badgeitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `badges_badgelayout`
--

DROP TABLE IF EXISTS `badges_badgelayout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `badges_badgelayout` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `default` tinyint(1) NOT NULL,
  `name` varchar(190) NOT NULL,
  `layout` longtext NOT NULL,
  `background` varchar(255) DEFAULT NULL,
  `event_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `badges_badgelayout_event_id_68746277_fk_pretixbase_event_id` (`event_id`),
  CONSTRAINT `badges_badgelayout_event_id_68746277_fk_pretixbase_event_id` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badges_badgelayout`
--

LOCK TABLES `badges_badgelayout` WRITE;
/*!40000 ALTER TABLE `badges_badgelayout` DISABLE KEYS */;
/*!40000 ALTER TABLE `badges_badgelayout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banktransfer_bankimportjob`
--

DROP TABLE IF EXISTS `banktransfer_bankimportjob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banktransfer_bankimportjob` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` datetime(6) NOT NULL,
  `state` varchar(32) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `organizer_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `banktransfer_bankimp_event_id_357c0b48_fk_pretixbas` (`event_id`),
  KEY `banktransfer_bankimp_organizer_id_77cbeb32_fk_pretixbas` (`organizer_id`),
  CONSTRAINT `banktransfer_bankimp_event_id_357c0b48_fk_pretixbas` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `banktransfer_bankimp_organizer_id_77cbeb32_fk_pretixbas` FOREIGN KEY (`organizer_id`) REFERENCES `pretixbase_organizer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banktransfer_bankimportjob`
--

LOCK TABLES `banktransfer_bankimportjob` WRITE;
/*!40000 ALTER TABLE `banktransfer_bankimportjob` DISABLE KEYS */;
/*!40000 ALTER TABLE `banktransfer_bankimportjob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banktransfer_banktransaction`
--

DROP TABLE IF EXISTS `banktransfer_banktransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banktransfer_banktransaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(32) NOT NULL,
  `message` longtext NOT NULL,
  `checksum` varchar(190) NOT NULL,
  `payer` longtext NOT NULL,
  `reference` longtext NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `date` varchar(50) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `import_job_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `comment` longtext NOT NULL,
  `organizer_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `banktransfer_banktransac_event_id_organizer_id_ch_2899b1f0_uniq` (`event_id`,`organizer_id`,`checksum`),
  KEY `banktransfer_banktra_order_id_f3ac8caf_fk_pretixbas` (`order_id`),
  KEY `banktransfer_banktransaction_checksum_b4d468c0` (`checksum`),
  KEY `banktransfer_banktra_import_job_id_b1439157_fk_banktrans` (`import_job_id`),
  KEY `banktransfer_banktransaction_event_id_96ac4f74` (`event_id`),
  KEY `banktransfer_banktra_organizer_id_a1995eea_fk_pretixbas` (`organizer_id`),
  CONSTRAINT `banktransfer_banktra_event_id_96ac4f74_fk_pretixbas` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `banktransfer_banktra_import_job_id_b1439157_fk_banktrans` FOREIGN KEY (`import_job_id`) REFERENCES `banktransfer_bankimportjob` (`id`),
  CONSTRAINT `banktransfer_banktra_order_id_f3ac8caf_fk_pretixbas` FOREIGN KEY (`order_id`) REFERENCES `pretixbase_order` (`id`),
  CONSTRAINT `banktransfer_banktra_organizer_id_a1995eea_fk_pretixbas` FOREIGN KEY (`organizer_id`) REFERENCES `pretixbase_organizer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banktransfer_banktransaction`
--

LOCK TABLES `banktransfer_banktransaction` WRITE;
/*!40000 ALTER TABLE `banktransfer_banktransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `banktransfer_banktransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (2,'auth','group'),(1,'auth','permission'),(79,'badges','badgeitem'),(80,'badges','badgelayout'),(71,'banktransfer','bankimportjob'),(72,'banktransfer','banktransaction'),(3,'contenttypes','contenttype'),(82,'otp_static','staticdevice'),(83,'otp_static','statictoken'),(81,'otp_totp','totpdevice'),(75,'paypal','referencedpaypalobject'),(69,'pretixapi','apicall'),(62,'pretixapi','oauthaccesstoken'),(63,'pretixapi','oauthapplication'),(64,'pretixapi','oauthgrant'),(65,'pretixapi','oauthrefreshtoken'),(66,'pretixapi','webhook'),(67,'pretixapi','webhookcall'),(68,'pretixapi','webhookeventlistener'),(29,'pretixbase','cachedcombinedticket'),(6,'pretixbase','cachedfile'),(7,'pretixbase','cachedticket'),(8,'pretixbase','cartposition'),(27,'pretixbase','checkin'),(46,'pretixbase','checkinlist'),(52,'pretixbase','device'),(9,'pretixbase','event'),(10,'pretixbase','eventlock'),(42,'pretixbase','eventmetaproperty'),(43,'pretixbase','eventmetavalue'),(31,'pretixbase','event_settingsstore'),(58,'pretixbase','giftcard'),(60,'pretixbase','giftcardacceptance'),(59,'pretixbase','giftcardtransaction'),(33,'pretixbase','globalsettingsobject_settingsstore'),(23,'pretixbase','invoice'),(22,'pretixbase','invoiceaddress'),(24,'pretixbase','invoiceline'),(11,'pretixbase','item'),(34,'pretixbase','itemaddon'),(53,'pretixbase','itembundle'),(12,'pretixbase','itemcategory'),(13,'pretixbase','itemvariation'),(14,'pretixbase','logentry'),(47,'pretixbase','notificationsetting'),(15,'pretixbase','order'),(45,'pretixbase','orderfee'),(50,'pretixbase','orderpayment'),(16,'pretixbase','orderposition'),(51,'pretixbase','orderrefund'),(17,'pretixbase','organizer'),(32,'pretixbase','organizer_settingsstore'),(18,'pretixbase','question'),(19,'pretixbase','questionanswer'),(25,'pretixbase','questionoption'),(20,'pretixbase','quota'),(28,'pretixbase','requiredaction'),(56,'pretixbase','seat'),(55,'pretixbase','seatcategorymapping'),(54,'pretixbase','seatingplan'),(48,'pretixbase','staffsession'),(49,'pretixbase','staffsessionauditlog'),(38,'pretixbase','subevent'),(39,'pretixbase','subeventitem'),(40,'pretixbase','subeventitemvariation'),(44,'pretixbase','subeventmetavalue'),(41,'pretixbase','taxrule'),(35,'pretixbase','team'),(37,'pretixbase','teamapitoken'),(36,'pretixbase','teaminvite'),(26,'pretixbase','u2fdevice'),(5,'pretixbase','user'),(21,'pretixbase','voucher'),(30,'pretixbase','waitinglistentry'),(57,'pretixbase','webauthndevice'),(78,'pretixdroid','appconfiguration'),(70,'pretixhelpers','thumbnail'),(61,'pretixmultidomain','knowndomain'),(4,'sessions','session'),(73,'stripe','referencedstripeobject'),(74,'stripe','registeredapplepaydomain'),(76,'ticketoutputpdf','ticketlayout'),(77,'ticketoutputpdf','ticketlayoutitem');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=234 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2020-02-17 20:19:25.356260'),(2,'contenttypes','0002_remove_content_type_name','2020-02-17 20:19:25.398392'),(3,'auth','0001_initial','2020-02-17 20:19:25.436605'),(4,'auth','0002_alter_permission_name_max_length','2020-02-17 20:19:25.513881'),(5,'auth','0003_alter_user_email_max_length','2020-02-17 20:19:25.520086'),(6,'auth','0004_alter_user_username_opts','2020-02-17 20:19:25.527691'),(7,'auth','0005_alter_user_last_login_null','2020-02-17 20:19:25.535722'),(8,'auth','0006_require_contenttypes_0002','2020-02-17 20:19:25.538280'),(9,'auth','0007_alter_validators_add_error_messages','2020-02-17 20:19:25.544974'),(10,'auth','0008_alter_user_username_max_length','2020-02-17 20:19:25.551814'),(11,'auth','0009_alter_user_last_name_max_length','2020-02-17 20:19:25.558912'),(12,'auth','0010_alter_group_name_max_length','2020-02-17 20:19:25.570100'),(13,'auth','0011_update_proxy_permissions','2020-02-17 20:19:25.577822'),(14,'pretixbase','0001_initial','2020-02-17 20:19:27.659837'),(15,'pretixbase','0002_auto_20160209_0940','2020-02-17 20:19:27.663074'),(16,'pretixbase','0003_eventpermission_can_change_vouchers','2020-02-17 20:19:27.665977'),(17,'pretixbase','0004_auto_20160209_1023','2020-02-17 20:19:27.669128'),(18,'pretixbase','0005_auto_20160211_1459','2020-02-17 20:19:27.671988'),(19,'pretixbase','0006_auto_20160211_1630','2020-02-17 20:19:27.674970'),(20,'pretixbase','0007_auto_20160211_1710','2020-02-17 20:19:27.677909'),(21,'pretixbase','0008_invoiceaddress','2020-02-17 20:19:27.680645'),(22,'pretixbase','0009_auto_20160222_2002','2020-02-17 20:19:27.683410'),(23,'pretixbase','0010_orderposition_secret','2020-02-17 20:19:27.685934'),(24,'pretixbase','0011_auto_20160311_2052','2020-02-17 20:19:27.688503'),(25,'pretixbase','0012_auto_20160312_1040','2020-02-17 20:19:27.690870'),(26,'pretixbase','0013_invoice_locale','2020-02-17 20:19:27.693170'),(27,'pretixbase','0014_invoice_additional_text','2020-02-17 20:19:27.695540'),(28,'pretixbase','0015_auto_20160312_1924','2020-02-17 20:19:27.697859'),(29,'pretixbase','0016_voucher_variation','2020-02-17 20:19:27.700241'),(30,'pretixbase','0017_auto_20160324_1615','2020-02-17 20:19:27.702516'),(31,'pretixbase','0018_auto_20160326_1104','2020-02-17 20:19:27.704948'),(32,'pretixbase','0019_auto_20160326_1139','2020-02-17 20:19:27.706983'),(33,'pretixbase','0020_auto_20160418_2106','2020-02-17 20:19:27.709119'),(34,'pretixbase','0021_auto_20160418_2117','2020-02-17 20:19:27.711148'),(35,'pretixbase','0020_auto_20160421_1943','2020-02-17 20:19:27.713430'),(36,'pretixbase','0022_merge','2020-02-17 20:19:27.715659'),(37,'pretixbase','0023_auto_20160601_1039','2020-02-17 20:19:27.718009'),(38,'pretixbase','0024_auto_20160728_1725','2020-02-17 20:19:27.720268'),(39,'pretixbase','0025_auto_20160802_2202','2020-02-17 20:19:27.722396'),(40,'pretixbase','0026_order_comment','2020-02-17 20:19:27.724536'),(41,'pretixbase','0027_auto_20160815_1254','2020-02-17 20:19:27.726749'),(42,'pretixbase','0028_auto_20160816_1242','2020-02-17 20:19:27.728921'),(43,'pretixbase','0028_invoice_invoice_no_charfield','2020-02-17 20:19:29.282384'),(44,'pretixbase','0029_invoice_no_data','2020-02-17 20:19:29.330616'),(45,'pretixbase','0030_auto_20160816_0646','2020-02-17 20:19:29.424768'),(46,'pretixbase','0031_auto_20160816_0648','2020-02-17 20:19:30.353905'),(47,'pretixbase','0032_question_position','2020-02-17 20:19:30.356936'),(48,'pretixbase','0033_auto_20160821_2222','2020-02-17 20:19:30.359209'),(49,'pretixbase','0034_auto_20160830_1952','2020-02-17 20:19:30.361527'),(50,'pretixbase','0032_item_allow_cancel','2020-02-17 20:19:30.363846'),(51,'pretixbase','0033_auto_20160822_1044','2020-02-17 20:19:30.365960'),(52,'pretixbase','0035_merge','2020-02-17 20:19:30.367974'),(53,'pretixbase','0036_auto_20160902_0755','2020-02-17 20:19:30.370052'),(54,'pretixbase','0037_invoice_payment_provider_text','2020-02-17 20:19:30.372071'),(55,'pretixbase','0038_auto_20160924_1448','2020-02-17 20:19:30.374160'),(56,'pretixbase','0039_user_require_2fa','2020-02-17 20:19:30.376212'),(57,'pretixbase','0040_u2fdevice','2020-02-17 20:19:30.378305'),(58,'pretixbase','0041_auto_20161018_1654','2020-02-17 20:19:30.380521'),(59,'pretixbase','0042_order_expires','2020-02-17 20:19:30.382678'),(60,'pretixbase','0043_globalsetting','2020-02-17 20:19:30.384719'),(61,'pretixbase','0044_auto_20161101_1610','2020-02-17 20:19:30.386881'),(62,'pretixbase','0045_auto_20161108_1542','2020-02-17 20:19:30.388916'),(63,'pretixbase','0046_order_meta_info','2020-02-17 20:19:30.391060'),(64,'pretixbase','0047_auto_20161126_1300','2020-02-17 20:19:30.393225'),(65,'pretixbase','0048_auto_20161129_1330','2020-02-17 20:19:30.395335'),(66,'pretixdroid','0001_initial','2020-02-17 20:19:30.492879'),(67,'pretixdroid','0002_auto_20161208_1644','2020-02-17 20:19:30.547893'),(68,'pretixbase','0049_checkin','2020-02-17 20:19:30.579878'),(69,'pretixbase','0050_orderposition_positionid','2020-02-17 20:19:31.337880'),(70,'pretixbase','0051_auto_20161221_1720','2020-02-17 20:19:31.340563'),(71,'pretixbase','0052_auto_20161231_1533','2020-02-17 20:19:31.342869'),(72,'pretixbase','0053_auto_20170104_1252','2020-02-17 20:19:31.344906'),(73,'pretixbase','0054_auto_20170107_1058','2020-02-17 20:19:31.346952'),(74,'pretixbase','0055_organizerpermission_can_change_permissions','2020-02-17 20:19:31.348895'),(75,'pretixbase','0056_auto_20170107_1251','2020-02-17 20:19:31.350718'),(76,'pretixbase','0057_auto_20170107_1531','2020-02-17 20:19:31.352716'),(77,'pretixbase','0058_auto_20170107_1533','2020-02-17 20:19:31.354600'),(78,'pretixbase','0059_cachedcombinedticket','2020-02-17 20:19:31.356505'),(79,'pretixbase','0060_auto_20170113_1438','2020-02-17 20:19:31.358473'),(80,'pretixbase','0061_event_location','2020-02-17 20:19:31.360507'),(81,'pretixbase','0051_auto_20170206_2027','2020-02-17 20:19:32.333995'),(82,'pretixbase','0052_auto_20170324_1506','2020-02-17 20:19:32.337357'),(83,'pretixbase','0053_auto_20170409_1651','2020-02-17 20:19:32.339974'),(84,'pretixbase','0054_auto_20170413_1050','2020-02-17 20:19:32.342335'),(85,'pretixbase','0055_auto_20170413_1537','2020-02-17 20:19:32.344659'),(86,'pretixbase','0056_auto_20170414_1044','2020-02-17 20:19:32.346712'),(87,'pretixbase','0057_auto_20170501_2116','2020-02-17 20:19:32.348893'),(88,'pretixbase','0052_team_teaminvite','2020-02-17 20:19:34.085579'),(89,'pretixbase','0058_auto_20170429_1020','2020-02-17 20:19:34.092051'),(90,'pretixbase','0059_checkin_nonce','2020-02-17 20:19:34.095292'),(91,'pretixbase','0060_auto_20170510_1027','2020-02-17 20:19:34.098004'),(92,'pretixbase','0061_auto_20170521_0942','2020-02-17 20:19:34.101342'),(93,'pretixbase','0062_auto_20170602_0948','2020-02-17 20:19:34.104503'),(94,'pretixbase','0063_auto_20170702_1711','2020-02-17 20:19:34.107856'),(95,'pretixbase','0064_auto_20170703_0912','2020-02-17 20:19:34.111250'),(96,'pretixbase','0065_auto_20170707_0920','2020-02-17 20:19:34.114369'),(97,'pretixbase','0066_auto_20170708_2102','2020-02-17 20:19:34.117024'),(98,'pretixbase','0067_auto_20170712_1610','2020-02-17 20:19:34.119688'),(99,'pretixbase','0068_subevent_frontpage_text','2020-02-17 20:19:34.122813'),(100,'pretixbase','0069_invoice_prefix','2020-02-17 20:19:34.125356'),(101,'pretixbase','0070_auto_20170719_0910','2020-02-17 20:19:34.127698'),(102,'pretixbase','0071_auto_20170729_1616','2020-02-17 20:19:35.497081'),(103,'pretixbase','0072_order_download_reminder_sent','2020-02-17 20:19:35.499620'),(104,'pretixbase','0073_auto_20170716_1333','2020-02-17 20:19:35.501846'),(105,'pretixbase','0074_auto_20170825_1258','2020-02-17 20:19:35.503930'),(106,'pretixbase','0075_auto_20170828_0901','2020-02-17 20:19:35.505994'),(107,'pretixbase','0076_orderfee','2020-02-17 20:19:36.632944'),(108,'pretixbase','0077_auto_20170829_1126','2020-02-17 20:19:36.635953'),(109,'pretixbase','0078_auto_20171003_1650','2020-02-17 20:19:36.638485'),(110,'pretixbase','0079_auto_20171010_2117','2020-02-17 20:19:36.640876'),(111,'pretixbase','0080_auto_20171016_1553','2020-02-17 20:19:36.643272'),(112,'pretixbase','0081_quota_cached_availability_paid_orders','2020-02-17 20:19:36.645447'),(113,'pretixbase','0082_invoiceaddress_internal_reference','2020-02-17 20:19:36.647576'),(114,'pretixbase','0077_auto_20171124_1629','2020-02-17 20:19:38.692061'),(115,'pretixbase','0078_auto_20171206_1603','2020-02-17 20:19:38.695005'),(116,'pretixbase','0079_auto_20180115_0855','2020-02-17 20:19:38.697494'),(117,'pretixbase','0080_question_ask_during_checkin','2020-02-17 20:19:38.699957'),(118,'pretixbase','0081_auto_20180220_1031','2020-02-17 20:19:38.702340'),(119,'pretixbase','0082_auto_20180222_0938','2020-02-17 20:19:38.704726'),(120,'pretixbase','0083_auto_20180228_2102','2020-02-17 20:19:38.707380'),(121,'pretixbase','0084_questionoption_position','2020-02-17 20:19:38.709726'),(122,'pretixbase','0085_auto_20180312_1119','2020-02-17 20:19:38.712221'),(123,'pretixbase','0086_auto_20180320_1219','2020-02-17 20:19:38.714558'),(124,'pretixbase','0087_auto_20180317_1952','2020-02-17 20:19:38.716738'),(125,'pretixbase','0088_auto_20180328_1217','2020-02-17 20:19:38.718930'),(126,'badges','0001_initial','2020-02-17 20:19:39.137745'),(127,'badges','0002_auto_20190201_1424','2020-02-17 20:19:39.407323'),(128,'banktransfer','0001_initial','2020-02-17 20:19:39.561467'),(129,'banktransfer','0002_auto_20160908_2020','2020-02-17 20:19:39.850741'),(130,'banktransfer','0003_banktransaction_comment','2020-02-17 20:19:39.896563'),(131,'banktransfer','0004_auto_20170619_1125','2020-02-17 20:19:40.232829'),(132,'banktransfer','0005_auto_20181023_2209','2020-02-17 20:19:40.364319'),(133,'oauth2_provider','0001_initial','2020-02-17 20:19:40.695581'),(134,'oauth2_provider','0002_08_updates','2020-02-17 20:19:40.802359'),(135,'oauth2_provider','0003_auto_20160316_1503','2020-02-17 20:19:40.858239'),(136,'oauth2_provider','0004_auto_20160525_1623','2020-02-17 20:19:40.908598'),(137,'oauth2_provider','0005_auto_20170514_1141','2020-02-17 20:19:41.248091'),(138,'oauth2_provider','0006_auto_20171214_2232','2020-02-17 20:19:41.382497'),(139,'otp_static','0001_initial','2020-02-17 20:19:41.498458'),(140,'otp_totp','0001_initial','2020-02-17 20:19:41.619137'),(141,'pretixapi','0001_initial','2020-02-17 20:19:42.223606'),(142,'pretixbase','0089_auto_20180315_1322','2020-02-17 20:19:42.576026'),(143,'pretixbase','0090_auto_20180509_0917','2020-02-17 20:19:43.171114'),(144,'pretixbase','0091_auto_20180513_1641','2020-02-17 20:19:43.174529'),(145,'pretixbase','0092_auto_20180511_1224','2020-02-17 20:19:43.177741'),(146,'pretixbase','0093_auto_20180528_1432','2020-02-17 20:19:43.180218'),(147,'pretixbase','0094_auto_20180604_1119','2020-02-17 20:19:43.183065'),(148,'pretixbase','0095_auto_20180604_1129','2020-02-17 20:19:43.185397'),(149,'pretixbase','0096_auto_20180722_0801','2020-02-17 20:19:43.539267'),(150,'pretixbase','0097_auto_20180722_0804','2020-02-17 20:19:44.069505'),(151,'paypal','0001_initial','2020-02-17 20:19:44.326872'),(152,'paypal','0002_referencedpaypalobject_payment','2020-02-17 20:19:44.415594'),(153,'pretixbase','0098_auto_20180731_1243','2020-02-17 20:19:45.166295'),(154,'pretixbase','0099_auto_20180807_0841','2020-02-17 20:19:45.169504'),(155,'pretixbase','0100_item_require_approval','2020-02-17 20:19:45.172386'),(156,'pretixbase','0099_auto_20180912_1035','2020-02-17 20:19:45.354365'),(157,'pretixbase','0100_auto_20181023_2300','2020-02-17 20:19:46.423377'),(158,'pretixbase','0101_auto_20181025_2255','2020-02-17 20:19:46.493976'),(159,'pretixbase','0102_auto_20181017_0024','2020-02-17 20:19:47.109488'),(160,'pretixbase','0103_auto_20181121_1224','2020-02-17 20:19:47.227717'),(161,'pretixbase','0104_auto_20181114_1526','2020-02-17 20:19:47.761357'),(162,'pretixbase','0105_auto_20190112_1512','2020-02-17 20:19:48.013416'),(163,'pretixbase','0106_auto_20190118_1527','2020-02-17 20:19:48.015676'),(164,'pretixbase','0107_auto_20190129_1337','2020-02-17 20:19:48.018033'),(165,'pretixbase','0108_auto_20190201_1527','2020-02-17 20:19:48.077079'),(166,'pretixbase','0109_auto_20190208_1432','2020-02-17 20:19:48.170920'),(167,'pretixbase','0110_auto_20190219_1245','2020-02-17 20:19:48.276084'),(168,'pretixbase','0111_auto_20190219_0949','2020-02-17 20:19:48.390757'),(169,'pretixbase','0112_auto_20190304_1726','2020-02-17 20:19:48.742644'),(170,'pretixbase','0113_auto_20190312_0942','2020-02-17 20:19:48.871931'),(171,'pretixbase','0114_auto_20190316_1014','2020-02-17 20:19:49.406483'),(172,'pretixbase','0115_auto_20190323_2238','2020-02-17 20:19:49.547829'),(173,'pretixbase','0116_auto_20190402_0722','2020-02-17 20:19:49.611381'),(174,'pretixapi','0002_auto_20180604_1120','2020-02-17 20:19:49.790668'),(175,'pretixapi','0003_webhook_webhookcall_webhookeventlistener','2020-02-17 20:19:50.211116'),(176,'pretixapi','0004_auto_20190405_1048','2020-02-17 20:19:50.356084'),(177,'pretixapi','0005_auto_20191028_1541','2020-02-17 20:19:50.418413'),(178,'pretixbase','0117_auto_20190418_1149','2020-02-17 20:19:50.455681'),(179,'pretixbase','0118_auto_20190423_0839','2020-02-17 20:19:50.497743'),(180,'pretixbase','0119_auto_20190509_0654','2020-02-17 20:19:50.536079'),(181,'pretixbase','0120_auto_20190509_0736','2020-02-17 20:19:51.233763'),(182,'pretixbase','0121_order_email_known_to_work','2020-02-17 20:19:51.298280'),(183,'pretixbase','0122_orderposition_web_secret','2020-02-17 20:19:51.579085'),(184,'pretixbase','0123_auto_20190530_1035','2020-02-17 20:19:52.168226'),(185,'pretixbase','0124_seat_seat_guid','2020-02-17 20:19:52.464730'),(186,'pretixbase','0125_voucher_show_hidden_items','2020-02-17 20:19:52.655470'),(187,'pretixbase','0126_item_show_quota_left','2020-02-17 20:19:52.731178'),(188,'pretixbase','0127_auto_20190711_0705','2020-02-17 20:19:52.902168'),(189,'pretixbase','0128_auto_20190715_1510','2020-02-17 20:19:53.044259'),(190,'pretixbase','0129_auto_20190724_1548','2020-02-17 20:19:53.134047'),(191,'pretixbase','0130_auto_20190729_1311','2020-02-17 20:19:53.364692'),(192,'pretixbase','0131_auto_20190729_1422','2020-02-17 20:19:53.440993'),(193,'pretixbase','0132_auto_20190808_1253','2020-02-17 20:19:53.559284'),(194,'pretixbase','0133_auto_20190830_1513','2020-02-17 20:19:53.846128'),(195,'pretixbase','0134_auto_20190909_1042','2020-02-17 20:19:53.938828'),(196,'pretixbase','0135_auto_20191007_0803','2020-02-17 20:19:54.073369'),(197,'pretixbase','0136_auto_20190918_1742','2020-02-17 20:19:54.142745'),(198,'pretixbase','0137_auto_20191015_1141','2020-02-17 20:19:54.173245'),(199,'pretixbase','0138_auto_20191017_1151','2020-02-17 20:19:54.920789'),(200,'pretixbase','0139_auto_20191019_1317','2020-02-17 20:19:55.414767'),(201,'pretixbase','0140_voucher_seat','2020-02-17 20:19:55.505714'),(202,'pretixbase','0141_seat_sorting_rank','2020-02-17 20:19:55.618659'),(203,'pretixbase','0142_auto_20191215_1522','2020-02-17 20:19:56.029683'),(204,'pretixdroid','0003_appconfiguration','2020-02-17 20:19:56.847234'),(205,'pretixdroid','0004_auto_20171124_1657','2020-02-17 20:19:56.850865'),(206,'pretixdroid','0005_auto_20180106_2122','2020-02-17 20:19:56.854058'),(207,'pretixhelpers','0001_initial','2020-02-17 20:19:57.010237'),(208,'pretixhelpers','0002_auto_20180320_1219','2020-02-17 20:19:57.024997'),(209,'pretixmultidomain','0001_initial','2020-02-17 20:19:57.104060'),(210,'sessions','0001_initial','2020-02-17 20:19:57.141676'),(211,'stripe','0001_initial','2020-02-17 20:19:57.230228'),(212,'stripe','0002_referencedstripeobject_payment','2020-02-17 20:19:57.353107'),(213,'stripe','0003_registeredapplepaydomain','2020-02-17 20:19:57.393173'),(214,'ticketoutputpdf','0001_initial','2020-02-17 20:19:57.592405'),(215,'ticketoutputpdf','0002_auto_20180605_2022','2020-02-17 20:19:57.786172'),(216,'ticketoutputpdf','0003_auto_20180710_1321','2020-02-17 20:19:57.911799'),(217,'ticketoutputpdf','0004_auto_20180805_1430','2020-02-17 20:19:58.038111'),(218,'ticketoutputpdf','0003_auto_20180805_1432','2020-02-17 20:19:58.434889'),(219,'ticketoutputpdf','0005_merge_20180805_1436','2020-02-17 20:19:58.439187'),(220,'ticketoutputpdf','0006_auto_20181017_0024','2020-02-17 20:19:58.517771'),(221,'ticketoutputpdf','0007_auto_20181123_1059','2020-02-17 20:19:58.735380'),(222,'pretixbase','0031_auto_20160816_0648_squashed_0048_auto_20161129_1330','2020-02-17 20:19:58.740842'),(223,'pretixbase','0076_orderfee_squashed_0082_invoiceaddress_internal_reference','2020-02-17 20:19:58.743891'),(224,'pretixbase','0077_auto_20171124_1629_squashed_0088_auto_20180328_1217','2020-02-17 20:19:58.746514'),(225,'pretixbase','0050_orderposition_positionid_squashed_0061_event_location','2020-02-17 20:19:58.748771'),(226,'pretixbase','0105_auto_20190112_1512_squashed_0107_auto_20190129_1337','2020-02-17 20:19:58.751567'),(227,'pretixbase','0090_auto_20180509_0917_squashed_0095_auto_20180604_1129','2020-02-17 20:19:58.754431'),(228,'pretixbase','0051_auto_20170206_2027_squashed_0057_auto_20170501_2116','2020-02-17 20:19:58.758196'),(229,'pretixbase','0071_auto_20170729_1616_squashed_0075_auto_20170828_0901','2020-02-17 20:19:58.763180'),(230,'pretixbase','0098_auto_20180731_1243_squashed_0100_item_require_approval','2020-02-17 20:19:58.767149'),(231,'pretixbase','0052_team_teaminvite_squashed_0070_auto_20170719_0910','2020-02-17 20:19:58.770309'),(232,'pretixbase','0001_squashed_0028_auto_20160816_1242','2020-02-17 20:19:58.773545'),(233,'pretixdroid','0003_appconfiguration_squashed_0005_auto_20180106_2122','2020-02-17 20:19:58.776596');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otp_static_staticdevice`
--

DROP TABLE IF EXISTS `otp_static_staticdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `otp_static_staticdevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `confirmed` tinyint(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `otp_static_staticdevice_user_id_7f9cff2b_fk_pretixbase_user_id` (`user_id`),
  CONSTRAINT `otp_static_staticdevice_user_id_7f9cff2b_fk_pretixbase_user_id` FOREIGN KEY (`user_id`) REFERENCES `pretixbase_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otp_static_staticdevice`
--

LOCK TABLES `otp_static_staticdevice` WRITE;
/*!40000 ALTER TABLE `otp_static_staticdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `otp_static_staticdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otp_static_statictoken`
--

DROP TABLE IF EXISTS `otp_static_statictoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `otp_static_statictoken` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(16) NOT NULL,
  `device_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `otp_static_statictok_device_id_74b7c7d1_fk_otp_stati` (`device_id`),
  KEY `otp_static_statictoken_token_d0a51866` (`token`),
  CONSTRAINT `otp_static_statictok_device_id_74b7c7d1_fk_otp_stati` FOREIGN KEY (`device_id`) REFERENCES `otp_static_staticdevice` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otp_static_statictoken`
--

LOCK TABLES `otp_static_statictoken` WRITE;
/*!40000 ALTER TABLE `otp_static_statictoken` DISABLE KEYS */;
/*!40000 ALTER TABLE `otp_static_statictoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otp_totp_totpdevice`
--

DROP TABLE IF EXISTS `otp_totp_totpdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `otp_totp_totpdevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `confirmed` tinyint(1) NOT NULL,
  `key` varchar(80) NOT NULL,
  `step` smallint(5) unsigned NOT NULL,
  `t0` bigint(20) NOT NULL,
  `digits` smallint(5) unsigned NOT NULL,
  `tolerance` smallint(5) unsigned NOT NULL,
  `drift` smallint(6) NOT NULL,
  `last_t` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `otp_totp_totpdevice_user_id_0fb18292_fk_pretixbase_user_id` (`user_id`),
  CONSTRAINT `otp_totp_totpdevice_user_id_0fb18292_fk_pretixbase_user_id` FOREIGN KEY (`user_id`) REFERENCES `pretixbase_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otp_totp_totpdevice`
--

LOCK TABLES `otp_totp_totpdevice` WRITE;
/*!40000 ALTER TABLE `otp_totp_totpdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `otp_totp_totpdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paypal_referencedpaypalobject`
--

DROP TABLE IF EXISTS `paypal_referencedpaypalobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paypal_referencedpaypalobject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(190) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `paypal_referencedpay_order_id_969d6ded_fk_pretixbas` (`order_id`),
  KEY `paypal_referencedpay_payment_id_430996e6_fk_pretixbas` (`payment_id`),
  CONSTRAINT `paypal_referencedpay_order_id_969d6ded_fk_pretixbas` FOREIGN KEY (`order_id`) REFERENCES `pretixbase_order` (`id`),
  CONSTRAINT `paypal_referencedpay_payment_id_430996e6_fk_pretixbas` FOREIGN KEY (`payment_id`) REFERENCES `pretixbase_orderpayment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paypal_referencedpaypalobject`
--

LOCK TABLES `paypal_referencedpaypalobject` WRITE;
/*!40000 ALTER TABLE `paypal_referencedpaypalobject` DISABLE KEYS */;
/*!40000 ALTER TABLE `paypal_referencedpaypalobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixapi_apicall`
--

DROP TABLE IF EXISTS `pretixapi_apicall`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixapi_apicall` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idempotency_key` varchar(190) NOT NULL,
  `auth_hash` varchar(190) NOT NULL,
  `created` datetime(6) NOT NULL,
  `locked` datetime(6) DEFAULT NULL,
  `request_method` varchar(20) NOT NULL,
  `request_path` varchar(255) NOT NULL,
  `response_code` int(10) unsigned NOT NULL,
  `response_headers` longtext NOT NULL,
  `response_body` longblob NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixapi_apicall_idempotency_key_auth_hash_5fe25ccd_uniq` (`idempotency_key`,`auth_hash`),
  KEY `pretixapi_apicall_idempotency_key_227357ca` (`idempotency_key`),
  KEY `pretixapi_apicall_auth_hash_583cf520` (`auth_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixapi_apicall`
--

LOCK TABLES `pretixapi_apicall` WRITE;
/*!40000 ALTER TABLE `pretixapi_apicall` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixapi_apicall` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixapi_oauthaccesstoken`
--

DROP TABLE IF EXISTS `pretixapi_oauthaccesstoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixapi_oauthaccesstoken` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `token` varchar(255) NOT NULL,
  `expires` datetime(6) NOT NULL,
  `scope` longtext NOT NULL,
  `created` datetime(6) NOT NULL,
  `updated` datetime(6) NOT NULL,
  `application_id` bigint(20) DEFAULT NULL,
  `source_refresh_token_id` bigint(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  UNIQUE KEY `source_refresh_token_id` (`source_refresh_token_id`),
  KEY `pretixapi_oauthacces_application_id_245596a4_fk_pretixapi` (`application_id`),
  KEY `pretixapi_oauthacces_user_id_13eca036_fk_pretixbas` (`user_id`),
  CONSTRAINT `pretixapi_oauthacces_application_id_245596a4_fk_pretixapi` FOREIGN KEY (`application_id`) REFERENCES `pretixapi_oauthapplication` (`id`),
  CONSTRAINT `pretixapi_oauthacces_source_refresh_token_c63a223c_fk_pretixapi` FOREIGN KEY (`source_refresh_token_id`) REFERENCES `pretixapi_oauthrefreshtoken` (`id`),
  CONSTRAINT `pretixapi_oauthacces_user_id_13eca036_fk_pretixbas` FOREIGN KEY (`user_id`) REFERENCES `pretixbase_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixapi_oauthaccesstoken`
--

LOCK TABLES `pretixapi_oauthaccesstoken` WRITE;
/*!40000 ALTER TABLE `pretixapi_oauthaccesstoken` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixapi_oauthaccesstoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixapi_oauthaccesstoken_organizers`
--

DROP TABLE IF EXISTS `pretixapi_oauthaccesstoken_organizers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixapi_oauthaccesstoken_organizers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oauthaccesstoken_id` bigint(20) NOT NULL,
  `organizer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixapi_oauthaccesstok_oauthaccesstoken_id_orga_f73804a6_uniq` (`oauthaccesstoken_id`,`organizer_id`),
  KEY `pretixapi_oauthacces_organizer_id_226c8320_fk_pretixbas` (`organizer_id`),
  CONSTRAINT `pretixapi_oauthacces_oauthaccesstoken_id_fe612a29_fk_pretixapi` FOREIGN KEY (`oauthaccesstoken_id`) REFERENCES `pretixapi_oauthaccesstoken` (`id`),
  CONSTRAINT `pretixapi_oauthacces_organizer_id_226c8320_fk_pretixbas` FOREIGN KEY (`organizer_id`) REFERENCES `pretixbase_organizer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixapi_oauthaccesstoken_organizers`
--

LOCK TABLES `pretixapi_oauthaccesstoken_organizers` WRITE;
/*!40000 ALTER TABLE `pretixapi_oauthaccesstoken_organizers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixapi_oauthaccesstoken_organizers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixapi_oauthapplication`
--

DROP TABLE IF EXISTS `pretixapi_oauthapplication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixapi_oauthapplication` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `client_type` varchar(32) NOT NULL,
  `authorization_grant_type` varchar(32) NOT NULL,
  `skip_authorization` tinyint(1) NOT NULL,
  `created` datetime(6) NOT NULL,
  `updated` datetime(6) NOT NULL,
  `name` varchar(255) NOT NULL,
  `redirect_uris` longtext NOT NULL,
  `client_id` varchar(100) NOT NULL,
  `client_secret` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `client_id` (`client_id`),
  KEY `pretixapi_oauthappli_user_id_5c13458d_fk_pretixbas` (`user_id`),
  KEY `pretixapi_oauthapplication_client_secret_7e5b6efb` (`client_secret`),
  CONSTRAINT `pretixapi_oauthappli_user_id_5c13458d_fk_pretixbas` FOREIGN KEY (`user_id`) REFERENCES `pretixbase_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixapi_oauthapplication`
--

LOCK TABLES `pretixapi_oauthapplication` WRITE;
/*!40000 ALTER TABLE `pretixapi_oauthapplication` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixapi_oauthapplication` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixapi_oauthgrant`
--

DROP TABLE IF EXISTS `pretixapi_oauthgrant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixapi_oauthgrant` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `expires` datetime(6) NOT NULL,
  `redirect_uri` varchar(2500) NOT NULL,
  `scope` longtext NOT NULL,
  `created` datetime(6) NOT NULL,
  `updated` datetime(6) NOT NULL,
  `application_id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `pretixapi_oauthgrant_application_id_9862c02b_fk_pretixapi` (`application_id`),
  KEY `pretixapi_oauthgrant_user_id_62abb1d8_fk_pretixbase_user_id` (`user_id`),
  CONSTRAINT `pretixapi_oauthgrant_application_id_9862c02b_fk_pretixapi` FOREIGN KEY (`application_id`) REFERENCES `pretixapi_oauthapplication` (`id`),
  CONSTRAINT `pretixapi_oauthgrant_user_id_62abb1d8_fk_pretixbase_user_id` FOREIGN KEY (`user_id`) REFERENCES `pretixbase_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixapi_oauthgrant`
--

LOCK TABLES `pretixapi_oauthgrant` WRITE;
/*!40000 ALTER TABLE `pretixapi_oauthgrant` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixapi_oauthgrant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixapi_oauthgrant_organizers`
--

DROP TABLE IF EXISTS `pretixapi_oauthgrant_organizers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixapi_oauthgrant_organizers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oauthgrant_id` bigint(20) NOT NULL,
  `organizer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixapi_oauthgrant_org_oauthgrant_id_organizer__201ea26a_uniq` (`oauthgrant_id`,`organizer_id`),
  KEY `pretixapi_oauthgrant_organizer_id_96dfce8f_fk_pretixbas` (`organizer_id`),
  CONSTRAINT `pretixapi_oauthgrant_oauthgrant_id_993176dd_fk_pretixapi` FOREIGN KEY (`oauthgrant_id`) REFERENCES `pretixapi_oauthgrant` (`id`),
  CONSTRAINT `pretixapi_oauthgrant_organizer_id_96dfce8f_fk_pretixbas` FOREIGN KEY (`organizer_id`) REFERENCES `pretixbase_organizer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixapi_oauthgrant_organizers`
--

LOCK TABLES `pretixapi_oauthgrant_organizers` WRITE;
/*!40000 ALTER TABLE `pretixapi_oauthgrant_organizers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixapi_oauthgrant_organizers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixapi_oauthrefreshtoken`
--

DROP TABLE IF EXISTS `pretixapi_oauthrefreshtoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixapi_oauthrefreshtoken` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `token` varchar(255) NOT NULL,
  `created` datetime(6) NOT NULL,
  `updated` datetime(6) NOT NULL,
  `revoked` datetime(6) DEFAULT NULL,
  `access_token_id` bigint(20) DEFAULT NULL,
  `application_id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `access_token_id` (`access_token_id`),
  UNIQUE KEY `pretixapi_oauthrefreshtoken_token_revoked_677b5bd0_uniq` (`token`,`revoked`),
  KEY `pretixapi_oauthrefre_application_id_a7e865e1_fk_pretixapi` (`application_id`),
  KEY `pretixapi_oauthrefre_user_id_a24feddf_fk_pretixbas` (`user_id`),
  CONSTRAINT `pretixapi_oauthrefre_access_token_id_a2b77010_fk_pretixapi` FOREIGN KEY (`access_token_id`) REFERENCES `pretixapi_oauthaccesstoken` (`id`),
  CONSTRAINT `pretixapi_oauthrefre_application_id_a7e865e1_fk_pretixapi` FOREIGN KEY (`application_id`) REFERENCES `pretixapi_oauthapplication` (`id`),
  CONSTRAINT `pretixapi_oauthrefre_user_id_a24feddf_fk_pretixbas` FOREIGN KEY (`user_id`) REFERENCES `pretixbase_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixapi_oauthrefreshtoken`
--

LOCK TABLES `pretixapi_oauthrefreshtoken` WRITE;
/*!40000 ALTER TABLE `pretixapi_oauthrefreshtoken` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixapi_oauthrefreshtoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixapi_webhook`
--

DROP TABLE IF EXISTS `pretixapi_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixapi_webhook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enabled` tinyint(1) NOT NULL,
  `target_url` varchar(200) NOT NULL,
  `all_events` tinyint(1) NOT NULL,
  `organizer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixapi_webhook_organizer_id_10a41f04_fk_pretixbas` (`organizer_id`),
  CONSTRAINT `pretixapi_webhook_organizer_id_10a41f04_fk_pretixbas` FOREIGN KEY (`organizer_id`) REFERENCES `pretixbase_organizer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixapi_webhook`
--

LOCK TABLES `pretixapi_webhook` WRITE;
/*!40000 ALTER TABLE `pretixapi_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixapi_webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixapi_webhook_limit_events`
--

DROP TABLE IF EXISTS `pretixapi_webhook_limit_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixapi_webhook_limit_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `webhook_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixapi_webhook_limit_events_webhook_id_event_id_12b0d459_uniq` (`webhook_id`,`event_id`),
  KEY `pretixapi_webhook_li_event_id_76919dfd_fk_pretixbas` (`event_id`),
  CONSTRAINT `pretixapi_webhook_li_event_id_76919dfd_fk_pretixbas` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `pretixapi_webhook_li_webhook_id_763c4a3f_fk_pretixapi` FOREIGN KEY (`webhook_id`) REFERENCES `pretixapi_webhook` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixapi_webhook_limit_events`
--

LOCK TABLES `pretixapi_webhook_limit_events` WRITE;
/*!40000 ALTER TABLE `pretixapi_webhook_limit_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixapi_webhook_limit_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixapi_webhookcall`
--

DROP TABLE IF EXISTS `pretixapi_webhookcall`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixapi_webhookcall` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime(6) NOT NULL,
  `target_url` varchar(200) NOT NULL,
  `is_retry` tinyint(1) NOT NULL,
  `execution_time` double DEFAULT NULL,
  `return_code` int(10) unsigned NOT NULL,
  `payload` longtext NOT NULL,
  `response_body` longtext NOT NULL,
  `webhook_id` int(11) NOT NULL,
  `success` tinyint(1) NOT NULL,
  `action_type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixapi_webhookcal_webhook_id_e138c438_fk_pretixapi` (`webhook_id`),
  CONSTRAINT `pretixapi_webhookcal_webhook_id_e138c438_fk_pretixapi` FOREIGN KEY (`webhook_id`) REFERENCES `pretixapi_webhook` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixapi_webhookcall`
--

LOCK TABLES `pretixapi_webhookcall` WRITE;
/*!40000 ALTER TABLE `pretixapi_webhookcall` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixapi_webhookcall` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixapi_webhookeventlistener`
--

DROP TABLE IF EXISTS `pretixapi_webhookeventlistener`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixapi_webhookeventlistener` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_type` varchar(255) NOT NULL,
  `webhook_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixapi_webhookeve_webhook_id_5518ad8d_fk_pretixapi` (`webhook_id`),
  CONSTRAINT `pretixapi_webhookeve_webhook_id_5518ad8d_fk_pretixapi` FOREIGN KEY (`webhook_id`) REFERENCES `pretixapi_webhook` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixapi_webhookeventlistener`
--

LOCK TABLES `pretixapi_webhookeventlistener` WRITE;
/*!40000 ALTER TABLE `pretixapi_webhookeventlistener` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixapi_webhookeventlistener` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_cachedcombinedticket`
--

DROP TABLE IF EXISTS `pretixbase_cachedcombinedticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_cachedcombinedticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provider` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `extension` varchar(255) NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `order_id` int(11) NOT NULL,
  `created` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_cachedcom_order_id_45509bc4_fk_pretixbas` (`order_id`),
  CONSTRAINT `pretixbase_cachedcom_order_id_45509bc4_fk_pretixbas` FOREIGN KEY (`order_id`) REFERENCES `pretixbase_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_cachedcombinedticket`
--

LOCK TABLES `pretixbase_cachedcombinedticket` WRITE;
/*!40000 ALTER TABLE `pretixbase_cachedcombinedticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_cachedcombinedticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_cachedfile`
--

DROP TABLE IF EXISTS `pretixbase_cachedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_cachedfile` (
  `id` char(32) NOT NULL,
  `expires` datetime(6) DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `file` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_cachedfile`
--

LOCK TABLES `pretixbase_cachedfile` WRITE;
/*!40000 ALTER TABLE `pretixbase_cachedfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_cachedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_cachedticket`
--

DROP TABLE IF EXISTS `pretixbase_cachedticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_cachedticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provider` varchar(255) NOT NULL,
  `order_position_id` int(11) NOT NULL,
  `extension` varchar(255) NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `created` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_cachedtic_order_position_id_b2c232a6_fk_pretixbas` (`order_position_id`),
  CONSTRAINT `pretixbase_cachedtic_order_position_id_b2c232a6_fk_pretixbas` FOREIGN KEY (`order_position_id`) REFERENCES `pretixbase_orderposition` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_cachedticket`
--

LOCK TABLES `pretixbase_cachedticket` WRITE;
/*!40000 ALTER TABLE `pretixbase_cachedticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_cachedticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_cartposition`
--

DROP TABLE IF EXISTS `pretixbase_cartposition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_cartposition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` decimal(10,2) NOT NULL,
  `attendee_name_cached` varchar(255) DEFAULT NULL,
  `cart_id` varchar(255) DEFAULT NULL,
  `datetime` datetime(6) NOT NULL,
  `expires` datetime(6) NOT NULL,
  `event_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `variation_id` int(11) DEFAULT NULL,
  `voucher_id` int(11) DEFAULT NULL,
  `attendee_email` varchar(254) DEFAULT NULL,
  `addon_to_id` int(11) DEFAULT NULL,
  `meta_info` longtext DEFAULT NULL,
  `subevent_id` int(11) DEFAULT NULL,
  `includes_tax` tinyint(1) NOT NULL,
  `attendee_name_parts` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `is_bundled` tinyint(1) NOT NULL,
  `seat_id` int(11) DEFAULT NULL,
  `price_before_voucher` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_cartposition_event_id_c8039949_fk_pretixbase_event_id` (`event_id`),
  KEY `pretixbase_cartposition_item_id_453bc23d_fk_pretixbase_item_id` (`item_id`),
  KEY `pretixbase_cartposit_variation_id_af1f0dfd_fk_pretixbas` (`variation_id`),
  KEY `pretixbase_cartposition_expires_d987d4e5` (`expires`),
  KEY `pretixbase_cartposition_cart_id_9d9be54b` (`cart_id`),
  KEY `pretixbase_cartposit_addon_to_id_d9ab2dee_fk_pretixbas` (`addon_to_id`),
  KEY `pretixbase_cartposit_subevent_id_8adb3b32_fk_pretixbas` (`subevent_id`),
  KEY `pretixbase_cartposit_voucher_id_a79e1879_fk_pretixbas` (`voucher_id`),
  KEY `pretixbase_cartposition_seat_id_1b6c3faf_fk_pretixbase_seat_id` (`seat_id`),
  CONSTRAINT `pretixbase_cartposit_addon_to_id_d9ab2dee_fk_pretixbas` FOREIGN KEY (`addon_to_id`) REFERENCES `pretixbase_cartposition` (`id`),
  CONSTRAINT `pretixbase_cartposit_subevent_id_8adb3b32_fk_pretixbas` FOREIGN KEY (`subevent_id`) REFERENCES `pretixbase_subevent` (`id`),
  CONSTRAINT `pretixbase_cartposit_variation_id_af1f0dfd_fk_pretixbas` FOREIGN KEY (`variation_id`) REFERENCES `pretixbase_itemvariation` (`id`),
  CONSTRAINT `pretixbase_cartposit_voucher_id_a79e1879_fk_pretixbas` FOREIGN KEY (`voucher_id`) REFERENCES `pretixbase_voucher` (`id`),
  CONSTRAINT `pretixbase_cartposition_event_id_c8039949_fk_pretixbase_event_id` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `pretixbase_cartposition_item_id_453bc23d_fk_pretixbase_item_id` FOREIGN KEY (`item_id`) REFERENCES `pretixbase_item` (`id`),
  CONSTRAINT `pretixbase_cartposition_seat_id_1b6c3faf_fk_pretixbase_seat_id` FOREIGN KEY (`seat_id`) REFERENCES `pretixbase_seat` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_cartposition`
--

LOCK TABLES `pretixbase_cartposition` WRITE;
/*!40000 ALTER TABLE `pretixbase_cartposition` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_cartposition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_checkin`
--

DROP TABLE IF EXISTS `pretixbase_checkin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_checkin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime(6) NOT NULL,
  `position_id` int(11) NOT NULL,
  `nonce` varchar(190) DEFAULT NULL,
  `list_id` int(11) NOT NULL,
  `auto_checked_in` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_checkin_list_id_position_id_cfc62e17_uniq` (`list_id`,`position_id`),
  KEY `pretixbase_checkin_position_id_2b4241d7_fk_pretixbas` (`position_id`),
  CONSTRAINT `pretixbase_checkin_list_id_edd48d9f_fk_pretixbase_checkinlist_id` FOREIGN KEY (`list_id`) REFERENCES `pretixbase_checkinlist` (`id`),
  CONSTRAINT `pretixbase_checkin_position_id_2b4241d7_fk_pretixbas` FOREIGN KEY (`position_id`) REFERENCES `pretixbase_orderposition` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_checkin`
--

LOCK TABLES `pretixbase_checkin` WRITE;
/*!40000 ALTER TABLE `pretixbase_checkin` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_checkin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_checkinlist`
--

DROP TABLE IF EXISTS `pretixbase_checkinlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_checkinlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(190) NOT NULL,
  `all_products` tinyint(1) NOT NULL,
  `event_id` int(11) NOT NULL,
  `subevent_id` int(11) DEFAULT NULL,
  `include_pending` tinyint(1) NOT NULL,
  `auto_checkin_sales_channels` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_checkinlist_event_id_cf987659_fk_pretixbase_event_id` (`event_id`),
  KEY `pretixbase_checkinli_subevent_id_bd5b8106_fk_pretixbas` (`subevent_id`),
  CONSTRAINT `pretixbase_checkinli_subevent_id_bd5b8106_fk_pretixbas` FOREIGN KEY (`subevent_id`) REFERENCES `pretixbase_subevent` (`id`),
  CONSTRAINT `pretixbase_checkinlist_event_id_cf987659_fk_pretixbase_event_id` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_checkinlist`
--

LOCK TABLES `pretixbase_checkinlist` WRITE;
/*!40000 ALTER TABLE `pretixbase_checkinlist` DISABLE KEYS */;
INSERT INTO `pretixbase_checkinlist` VALUES (3,'Template (series) - Jan. 1, 2001',1,3,1,0,''),(4,'Default',1,4,NULL,0,'');
/*!40000 ALTER TABLE `pretixbase_checkinlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_checkinlist_limit_products`
--

DROP TABLE IF EXISTS `pretixbase_checkinlist_limit_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_checkinlist_limit_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `checkinlist_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_checkinlist_l_checkinlist_id_item_id_ba1c66d0_uniq` (`checkinlist_id`,`item_id`),
  KEY `pretixbase_checkinli_item_id_d88aefb1_fk_pretixbas` (`item_id`),
  CONSTRAINT `pretixbase_checkinli_checkinlist_id_95aa970b_fk_pretixbas` FOREIGN KEY (`checkinlist_id`) REFERENCES `pretixbase_checkinlist` (`id`),
  CONSTRAINT `pretixbase_checkinli_item_id_d88aefb1_fk_pretixbas` FOREIGN KEY (`item_id`) REFERENCES `pretixbase_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_checkinlist_limit_products`
--

LOCK TABLES `pretixbase_checkinlist_limit_products` WRITE;
/*!40000 ALTER TABLE `pretixbase_checkinlist_limit_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_checkinlist_limit_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_device`
--

DROP TABLE IF EXISTS `pretixbase_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_device` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(10) unsigned NOT NULL,
  `unique_serial` varchar(190) NOT NULL,
  `initialization_token` varchar(190) NOT NULL,
  `api_token` varchar(190) DEFAULT NULL,
  `all_events` tinyint(1) NOT NULL,
  `name` varchar(190) NOT NULL,
  `created` datetime(6) NOT NULL,
  `initialized` datetime(6) DEFAULT NULL,
  `hardware_brand` varchar(190) DEFAULT NULL,
  `hardware_model` varchar(190) DEFAULT NULL,
  `software_brand` varchar(190) DEFAULT NULL,
  `software_version` varchar(190) DEFAULT NULL,
  `organizer_id` int(11) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_serial` (`unique_serial`),
  UNIQUE KEY `initialization_token` (`initialization_token`),
  UNIQUE KEY `pretixbase_device_organizer_id_device_id_524c771f_uniq` (`organizer_id`,`device_id`),
  UNIQUE KEY `api_token` (`api_token`),
  CONSTRAINT `pretixbase_device_organizer_id_1fab75fa_fk_pretixbas` FOREIGN KEY (`organizer_id`) REFERENCES `pretixbase_organizer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_device`
--

LOCK TABLES `pretixbase_device` WRITE;
/*!40000 ALTER TABLE `pretixbase_device` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_device_limit_events`
--

DROP TABLE IF EXISTS `pretixbase_device_limit_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_device_limit_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_device_limit_events_device_id_event_id_0946afc6_uniq` (`device_id`,`event_id`),
  KEY `pretixbase_device_li_event_id_cabc9720_fk_pretixbas` (`event_id`),
  CONSTRAINT `pretixbase_device_li_device_id_8c1335ff_fk_pretixbas` FOREIGN KEY (`device_id`) REFERENCES `pretixbase_device` (`id`),
  CONSTRAINT `pretixbase_device_li_event_id_cabc9720_fk_pretixbas` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_device_limit_events`
--

LOCK TABLES `pretixbase_device_limit_events` WRITE;
/*!40000 ALTER TABLE `pretixbase_device_limit_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_device_limit_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_event`
--

DROP TABLE IF EXISTS `pretixbase_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `slug` varchar(50) NOT NULL,
  `currency` varchar(10) NOT NULL,
  `date_from` datetime(6) NOT NULL,
  `date_to` datetime(6) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL,
  `presale_end` datetime(6) DEFAULT NULL,
  `presale_start` datetime(6) DEFAULT NULL,
  `plugins` longtext NOT NULL,
  `organizer_id` int(11) NOT NULL,
  `live` tinyint(1) NOT NULL,
  `location` longtext DEFAULT NULL,
  `date_admission` datetime(6) DEFAULT NULL,
  `comment` longtext DEFAULT NULL,
  `has_subevents` tinyint(1) NOT NULL,
  `testmode` tinyint(1) NOT NULL,
  `seating_plan_id` int(11) DEFAULT NULL,
  `geo_lat` double DEFAULT NULL,
  `geo_lon` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_event_organizer_id_slug_ef87d553_uniq` (`organizer_id`,`slug`),
  KEY `pretixbase_event_slug_8033ce26` (`slug`),
  KEY `pretixbase_event_seating_plan_id_11bc56fa_fk_pretixbas` (`seating_plan_id`),
  CONSTRAINT `pretixbase_event_organizer_id_f31b86fa_fk_pretixbas` FOREIGN KEY (`organizer_id`) REFERENCES `pretixbase_organizer` (`id`),
  CONSTRAINT `pretixbase_event_seating_plan_id_11bc56fa_fk_pretixbas` FOREIGN KEY (`seating_plan_id`) REFERENCES `pretixbase_seatingplan` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_event`
--

LOCK TABLES `pretixbase_event` WRITE;
/*!40000 ALTER TABLE `pretixbase_event` DISABLE KEYS */;
INSERT INTO `pretixbase_event` VALUES (3,'{\"da\": \"Skabelon (serie)\", \"en\": \"Template (series)\"}','template-series','DKK','2001-01-01 00:00:00.000000',NULL,1,NULL,NULL,'pretix.plugins.sendmail,pretix.plugins.statistics,pretix.plugins.checkinlists,pretix.plugins.autocheckin',1,0,'{}',NULL,NULL,1,1,NULL,NULL,NULL),(4,'{\"da\": \"Skabelon (enkeltst\\u00e5ende)\", \"en\": \"Template (single)\"}','template-single','DKK','2001-01-01 00:00:00.000000',NULL,1,NULL,NULL,'pretix.plugins.sendmail,pretix.plugins.statistics,pretix.plugins.checkinlists,pretix.plugins.autocheckin,pretix.plugins.ticketoutputpdf',1,0,'{}',NULL,NULL,0,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `pretixbase_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_event_settingsstore`
--

DROP TABLE IF EXISTS `pretixbase_event_settingsstore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_event_settingsstore` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` longtext NOT NULL,
  `object_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_event_set_object_id_961c7369_fk_pretixbas` (`object_id`),
  CONSTRAINT `pretixbase_event_set_object_id_961c7369_fk_pretixbas` FOREIGN KEY (`object_id`) REFERENCES `pretixbase_event` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_event_settingsstore`
--

LOCK TABLES `pretixbase_event_settingsstore` WRITE;
/*!40000 ALTER TABLE `pretixbase_event_settingsstore` DISABLE KEYS */;
INSERT INTO `pretixbase_event_settingsstore` VALUES (28,'invoice_renderer','modern1',3),(29,'invoice_include_expire_date','True',3),(30,'timezone','UTC',3),(31,'locale','en',3),(32,'locales','[\"en\", \"da\"]',3),(33,'invoice_renderer','modern1',4),(34,'invoice_include_expire_date','True',4),(35,'timezone','UTC',4),(36,'locale','en',4),(37,'locales','[\"en\", \"da\"]',4),(38,'ticket_download','True',4),(39,'ticketoutput_pdf__enabled','True',4),(40,'show_quota_left','False',4),(41,'waiting_list_enabled','True',4),(42,'attendee_names_required','False',4),(43,'contact_mail','',4),(44,'imprint_url','',4),(45,'payment_free__fee_reverse_calc','True',4),(46,'payment_boxoffice__fee_reverse_calc','True',4),(47,'payment_offsetting__fee_reverse_calc','True',4),(48,'payment_manual__fee_reverse_calc','True',4),(49,'payment_giftcard__fee_reverse_calc','True',4);
/*!40000 ALTER TABLE `pretixbase_event_settingsstore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_eventlock`
--

DROP TABLE IF EXISTS `pretixbase_eventlock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_eventlock` (
  `event` varchar(36) NOT NULL,
  `date` datetime(6) NOT NULL,
  `token` char(32) NOT NULL,
  PRIMARY KEY (`event`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_eventlock`
--

LOCK TABLES `pretixbase_eventlock` WRITE;
/*!40000 ALTER TABLE `pretixbase_eventlock` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_eventlock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_eventmetaproperty`
--

DROP TABLE IF EXISTS `pretixbase_eventmetaproperty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_eventmetaproperty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `default` longtext NOT NULL,
  `organizer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_eventmeta_organizer_id_595552fd_fk_pretixbas` (`organizer_id`),
  KEY `pretixbase_eventmetaproperty_name_c3ddda49` (`name`),
  CONSTRAINT `pretixbase_eventmeta_organizer_id_595552fd_fk_pretixbas` FOREIGN KEY (`organizer_id`) REFERENCES `pretixbase_organizer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_eventmetaproperty`
--

LOCK TABLES `pretixbase_eventmetaproperty` WRITE;
/*!40000 ALTER TABLE `pretixbase_eventmetaproperty` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_eventmetaproperty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_eventmetavalue`
--

DROP TABLE IF EXISTS `pretixbase_eventmetavalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_eventmetavalue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` longtext NOT NULL,
  `event_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_eventmetavalue_event_id_property_id_1844697e_uniq` (`event_id`,`property_id`),
  KEY `pretixbase_eventmeta_property_id_28f8ebf7_fk_pretixbas` (`property_id`),
  CONSTRAINT `pretixbase_eventmeta_event_id_567f5820_fk_pretixbas` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `pretixbase_eventmeta_property_id_28f8ebf7_fk_pretixbas` FOREIGN KEY (`property_id`) REFERENCES `pretixbase_eventmetaproperty` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_eventmetavalue`
--

LOCK TABLES `pretixbase_eventmetavalue` WRITE;
/*!40000 ALTER TABLE `pretixbase_eventmetavalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_eventmetavalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_giftcard`
--

DROP TABLE IF EXISTS `pretixbase_giftcard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_giftcard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issuance` datetime(6) NOT NULL,
  `secret` varchar(190) NOT NULL,
  `currency` varchar(10) NOT NULL,
  `issued_in_id` int(11) DEFAULT NULL,
  `issuer_id` int(11) NOT NULL,
  `testmode` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_giftcard_secret_issuer_id_fcc3d2d1_uniq` (`secret`,`issuer_id`),
  KEY `pretixbase_giftcard_issued_in_id_8e59beb9_fk_pretixbas` (`issued_in_id`),
  KEY `pretixbase_giftcard_issuer_id_57c2f4dd_fk_pretixbas` (`issuer_id`),
  KEY `pretixbase_giftcard_secret_8368bc5a` (`secret`),
  CONSTRAINT `pretixbase_giftcard_issued_in_id_8e59beb9_fk_pretixbas` FOREIGN KEY (`issued_in_id`) REFERENCES `pretixbase_orderposition` (`id`),
  CONSTRAINT `pretixbase_giftcard_issuer_id_57c2f4dd_fk_pretixbas` FOREIGN KEY (`issuer_id`) REFERENCES `pretixbase_organizer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_giftcard`
--

LOCK TABLES `pretixbase_giftcard` WRITE;
/*!40000 ALTER TABLE `pretixbase_giftcard` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_giftcard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_giftcardacceptance`
--

DROP TABLE IF EXISTS `pretixbase_giftcardacceptance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_giftcardacceptance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collector_id` int(11) NOT NULL,
  `issuer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_giftcarda_collector_id_13a50fa5_fk_pretixbas` (`collector_id`),
  KEY `pretixbase_giftcarda_issuer_id_740d7cdc_fk_pretixbas` (`issuer_id`),
  CONSTRAINT `pretixbase_giftcarda_collector_id_13a50fa5_fk_pretixbas` FOREIGN KEY (`collector_id`) REFERENCES `pretixbase_organizer` (`id`),
  CONSTRAINT `pretixbase_giftcarda_issuer_id_740d7cdc_fk_pretixbas` FOREIGN KEY (`issuer_id`) REFERENCES `pretixbase_organizer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_giftcardacceptance`
--

LOCK TABLES `pretixbase_giftcardacceptance` WRITE;
/*!40000 ALTER TABLE `pretixbase_giftcardacceptance` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_giftcardacceptance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_giftcardtransaction`
--

DROP TABLE IF EXISTS `pretixbase_giftcardtransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_giftcardtransaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime(6) NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `card_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `refund_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_giftcardt_card_id_2b213307_fk_pretixbas` (`card_id`),
  KEY `pretixbase_giftcardt_order_id_9cc06375_fk_pretixbas` (`order_id`),
  KEY `pretixbase_giftcardt_payment_id_21f4d416_fk_pretixbas` (`payment_id`),
  KEY `pretixbase_giftcardt_refund_id_4852a01b_fk_pretixbas` (`refund_id`),
  CONSTRAINT `pretixbase_giftcardt_card_id_2b213307_fk_pretixbas` FOREIGN KEY (`card_id`) REFERENCES `pretixbase_giftcard` (`id`),
  CONSTRAINT `pretixbase_giftcardt_order_id_9cc06375_fk_pretixbas` FOREIGN KEY (`order_id`) REFERENCES `pretixbase_order` (`id`),
  CONSTRAINT `pretixbase_giftcardt_payment_id_21f4d416_fk_pretixbas` FOREIGN KEY (`payment_id`) REFERENCES `pretixbase_orderpayment` (`id`),
  CONSTRAINT `pretixbase_giftcardt_refund_id_4852a01b_fk_pretixbas` FOREIGN KEY (`refund_id`) REFERENCES `pretixbase_orderrefund` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_giftcardtransaction`
--

LOCK TABLES `pretixbase_giftcardtransaction` WRITE;
/*!40000 ALTER TABLE `pretixbase_giftcardtransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_giftcardtransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_globalsettingsobject_settingsstore`
--

DROP TABLE IF EXISTS `pretixbase_globalsettingsobject_settingsstore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_globalsettingsobject_settingsstore` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_globalsettingsobject_settingsstore_key_c85c6d29` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_globalsettingsobject_settingsstore`
--

LOCK TABLES `pretixbase_globalsettingsobject_settingsstore` WRITE;
/*!40000 ALTER TABLE `pretixbase_globalsettingsobject_settingsstore` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_globalsettingsobject_settingsstore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_invoice`
--

DROP TABLE IF EXISTS `pretixbase_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_from` longtext NOT NULL,
  `invoice_to` longtext NOT NULL,
  `date` date NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `event_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `locale` varchar(50) NOT NULL,
  `additional_text` longtext NOT NULL,
  `is_cancellation` tinyint(1) NOT NULL,
  `refers_id` int(11) DEFAULT NULL,
  `invoice_no` varchar(19) NOT NULL,
  `footer_text` longtext NOT NULL,
  `introductory_text` longtext NOT NULL,
  `payment_provider_text` longtext NOT NULL,
  `prefix` varchar(160) NOT NULL,
  `organizer_id` int(11) NOT NULL,
  `foreign_currency_display` varchar(50) DEFAULT NULL,
  `foreign_currency_rate` decimal(10,4) DEFAULT NULL,
  `foreign_currency_rate_date` date DEFAULT NULL,
  `internal_reference` longtext NOT NULL,
  `full_invoice_no` varchar(190) NOT NULL,
  `shredded` tinyint(1) NOT NULL,
  `invoice_from_city` varchar(190) DEFAULT NULL,
  `invoice_from_country` varchar(2) DEFAULT NULL,
  `invoice_from_name` varchar(190) DEFAULT NULL,
  `invoice_from_tax_id` varchar(190) DEFAULT NULL,
  `invoice_from_vat_id` varchar(190) DEFAULT NULL,
  `invoice_from_zipcode` varchar(190) DEFAULT NULL,
  `invoice_to_city` longtext DEFAULT NULL,
  `invoice_to_company` longtext DEFAULT NULL,
  `invoice_to_country` varchar(2) DEFAULT NULL,
  `invoice_to_name` longtext DEFAULT NULL,
  `invoice_to_street` longtext DEFAULT NULL,
  `invoice_to_vat_id` longtext DEFAULT NULL,
  `invoice_to_zipcode` varchar(190) DEFAULT NULL,
  `reverse_charge` tinyint(1) NOT NULL,
  `invoice_to_beneficiary` longtext DEFAULT NULL,
  `invoice_to_state` varchar(190) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_invoice_organizer_id_prefix_invoice_no_8da728d2_uniq` (`organizer_id`,`prefix`,`invoice_no`),
  KEY `pretixbase_invoice_order_id_ffa32f5d_fk_pretixbase_order_id` (`order_id`),
  KEY `pretixbase_invoice_refers_id_6ccf8629_fk_pretixbase_invoice_id` (`refers_id`),
  KEY `pretixbase_invoice_invoice_no_charfield_e3e140c3` (`invoice_no`),
  KEY `pretixbase_invoice_event_id_4eb1793c` (`event_id`),
  KEY `pretixbase_invoice_prefix_b4c7163b` (`prefix`),
  KEY `pretixbase_invoice_full_invoice_no_ca155400` (`full_invoice_no`),
  CONSTRAINT `pretixbase_invoice_event_id_4eb1793c_fk_pretixbase_event_id` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `pretixbase_invoice_order_id_ffa32f5d_fk_pretixbase_order_id` FOREIGN KEY (`order_id`) REFERENCES `pretixbase_order` (`id`),
  CONSTRAINT `pretixbase_invoice_organizer_id_928d7304_fk_pretixbas` FOREIGN KEY (`organizer_id`) REFERENCES `pretixbase_organizer` (`id`),
  CONSTRAINT `pretixbase_invoice_refers_id_6ccf8629_fk_pretixbase_invoice_id` FOREIGN KEY (`refers_id`) REFERENCES `pretixbase_invoice` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_invoice`
--

LOCK TABLES `pretixbase_invoice` WRITE;
/*!40000 ALTER TABLE `pretixbase_invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_invoiceaddress`
--

DROP TABLE IF EXISTS `pretixbase_invoiceaddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_invoiceaddress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `last_modified` datetime(6) NOT NULL,
  `company` varchar(255) NOT NULL,
  `name_cached` varchar(255) NOT NULL,
  `street` longtext NOT NULL,
  `zipcode` varchar(30) NOT NULL,
  `city` varchar(255) NOT NULL,
  `country_old` varchar(255) NOT NULL,
  `vat_id` varchar(255) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `country` varchar(2) NOT NULL,
  `is_business` tinyint(1) NOT NULL,
  `vat_id_validated` tinyint(1) NOT NULL,
  `internal_reference` longtext NOT NULL,
  `name_parts` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `beneficiary` longtext NOT NULL,
  `state` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_id` (`order_id`),
  CONSTRAINT `pretixbase_invoicead_order_id_3e8d3c70_fk_pretixbas` FOREIGN KEY (`order_id`) REFERENCES `pretixbase_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_invoiceaddress`
--

LOCK TABLES `pretixbase_invoiceaddress` WRITE;
/*!40000 ALTER TABLE `pretixbase_invoiceaddress` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_invoiceaddress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_invoiceline`
--

DROP TABLE IF EXISTS `pretixbase_invoiceline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_invoiceline` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `gross_value` decimal(10,2) NOT NULL,
  `tax_value` decimal(10,2) NOT NULL,
  `tax_rate` decimal(7,2) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `tax_name` varchar(190) NOT NULL,
  `position` int(10) unsigned NOT NULL,
  `event_date_from` datetime(6) DEFAULT NULL,
  `subevent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_invoiceli_invoice_id_8e8da2c5_fk_pretixbas` (`invoice_id`),
  KEY `pretixbase_invoiceli_subevent_id_69f4adc8_fk_pretixbas` (`subevent_id`),
  CONSTRAINT `pretixbase_invoiceli_invoice_id_8e8da2c5_fk_pretixbas` FOREIGN KEY (`invoice_id`) REFERENCES `pretixbase_invoice` (`id`),
  CONSTRAINT `pretixbase_invoiceli_subevent_id_69f4adc8_fk_pretixbas` FOREIGN KEY (`subevent_id`) REFERENCES `pretixbase_subevent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_invoiceline`
--

LOCK TABLES `pretixbase_invoiceline` WRITE;
/*!40000 ALTER TABLE `pretixbase_invoiceline` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_invoiceline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_item`
--

DROP TABLE IF EXISTS `pretixbase_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `active` tinyint(1) NOT NULL,
  `description` longtext DEFAULT NULL,
  `default_price` decimal(7,2) DEFAULT NULL,
  `admission` tinyint(1) NOT NULL,
  `position` int(11) NOT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `available_from` datetime(6) DEFAULT NULL,
  `available_until` datetime(6) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `event_id` int(11) NOT NULL,
  `free_price` tinyint(1) NOT NULL,
  `hide_without_voucher` tinyint(1) NOT NULL,
  `require_voucher` tinyint(1) NOT NULL,
  `allow_cancel` tinyint(1) NOT NULL,
  `max_per_order` int(11) DEFAULT NULL,
  `min_per_order` int(11) DEFAULT NULL,
  `tax_rule_id` int(11) DEFAULT NULL,
  `checkin_attention` tinyint(1) NOT NULL,
  `internal_name` varchar(255) DEFAULT NULL,
  `original_price` decimal(7,2) DEFAULT NULL,
  `require_approval` tinyint(1) NOT NULL,
  `sales_channels` longtext NOT NULL,
  `generate_tickets` tinyint(1) DEFAULT NULL,
  `require_bundling` tinyint(1) NOT NULL,
  `show_quota_left` tinyint(1) DEFAULT NULL,
  `hidden_if_available_id` int(11) DEFAULT NULL,
  `allow_waitinglist` tinyint(1) NOT NULL,
  `issue_giftcard` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_item_event_id_6e8233b4_fk_pretixbase_event_id` (`event_id`),
  KEY `pretixbase_item_tax_rule_id_f501b784_fk_pretixbase_taxrule_id` (`tax_rule_id`),
  KEY `pretixbase_item_category_id_8fa63715_fk_pretixbas` (`category_id`),
  KEY `pretixbase_item_hidden_if_available__6d97361e_fk_pretixbas` (`hidden_if_available_id`),
  CONSTRAINT `pretixbase_item_category_id_8fa63715_fk_pretixbas` FOREIGN KEY (`category_id`) REFERENCES `pretixbase_itemcategory` (`id`),
  CONSTRAINT `pretixbase_item_event_id_6e8233b4_fk_pretixbase_event_id` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `pretixbase_item_hidden_if_available__6d97361e_fk_pretixbas` FOREIGN KEY (`hidden_if_available_id`) REFERENCES `pretixbase_quota` (`id`),
  CONSTRAINT `pretixbase_item_tax_rule_id_f501b784_fk_pretixbase_taxrule_id` FOREIGN KEY (`tax_rule_id`) REFERENCES `pretixbase_taxrule` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_item`
--

LOCK TABLES `pretixbase_item` WRITE;
/*!40000 ALTER TABLE `pretixbase_item` DISABLE KEYS */;
INSERT INTO `pretixbase_item` VALUES (3,'{\"da\": \"Billet\", \"en\": \"Ticket\"}',1,NULL,0.00,0,1,'',NULL,NULL,NULL,3,0,0,0,1,NULL,NULL,NULL,0,NULL,NULL,0,'web',NULL,0,NULL,NULL,1,0),(4,'{\"da\": \"Billet\", \"en\": \"Ticket\"}',1,NULL,0.00,1,0,'',NULL,NULL,2,4,0,0,0,1,NULL,NULL,NULL,0,NULL,NULL,0,'web',NULL,0,NULL,NULL,1,0);
/*!40000 ALTER TABLE `pretixbase_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_itemaddon`
--

DROP TABLE IF EXISTS `pretixbase_itemaddon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_itemaddon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `min_count` int(10) unsigned NOT NULL,
  `max_count` int(10) unsigned NOT NULL,
  `addon_category_id` int(11) NOT NULL,
  `base_item_id` int(11) NOT NULL,
  `position` int(10) unsigned NOT NULL,
  `price_included` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_itemaddon_base_item_id_addon_categ_8e09fedf_uniq` (`base_item_id`,`addon_category_id`),
  KEY `pretixbase_itemaddon_addon_category_id_370defeb_fk_pretixbas` (`addon_category_id`),
  CONSTRAINT `pretixbase_itemaddon_addon_category_id_370defeb_fk_pretixbas` FOREIGN KEY (`addon_category_id`) REFERENCES `pretixbase_itemcategory` (`id`),
  CONSTRAINT `pretixbase_itemaddon_base_item_id_1f94d65a_fk_pretixbase_item_id` FOREIGN KEY (`base_item_id`) REFERENCES `pretixbase_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_itemaddon`
--

LOCK TABLES `pretixbase_itemaddon` WRITE;
/*!40000 ALTER TABLE `pretixbase_itemaddon` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_itemaddon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_itembundle`
--

DROP TABLE IF EXISTS `pretixbase_itembundle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_itembundle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `count` int(10) unsigned NOT NULL,
  `designated_price` decimal(10,2) NOT NULL,
  `base_item_id` int(11) NOT NULL,
  `bundled_item_id` int(11) NOT NULL,
  `bundled_variation_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_itembundl_base_item_id_ac6691f3_fk_pretixbas` (`base_item_id`),
  KEY `pretixbase_itembundl_bundled_item_id_9f6f0a8f_fk_pretixbas` (`bundled_item_id`),
  KEY `pretixbase_itembundl_bundled_variation_id_cd1fba5f_fk_pretixbas` (`bundled_variation_id`),
  CONSTRAINT `pretixbase_itembundl_base_item_id_ac6691f3_fk_pretixbas` FOREIGN KEY (`base_item_id`) REFERENCES `pretixbase_item` (`id`),
  CONSTRAINT `pretixbase_itembundl_bundled_item_id_9f6f0a8f_fk_pretixbas` FOREIGN KEY (`bundled_item_id`) REFERENCES `pretixbase_item` (`id`),
  CONSTRAINT `pretixbase_itembundl_bundled_variation_id_cd1fba5f_fk_pretixbas` FOREIGN KEY (`bundled_variation_id`) REFERENCES `pretixbase_itemvariation` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_itembundle`
--

LOCK TABLES `pretixbase_itembundle` WRITE;
/*!40000 ALTER TABLE `pretixbase_itembundle` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_itembundle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_itemcategory`
--

DROP TABLE IF EXISTS `pretixbase_itemcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_itemcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `position` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `is_addon` tinyint(1) NOT NULL,
  `internal_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_itemcategory_event_id_0827a86a_fk_pretixbase_event_id` (`event_id`),
  CONSTRAINT `pretixbase_itemcategory_event_id_0827a86a_fk_pretixbase_event_id` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_itemcategory`
--

LOCK TABLES `pretixbase_itemcategory` WRITE;
/*!40000 ALTER TABLE `pretixbase_itemcategory` DISABLE KEYS */;
INSERT INTO `pretixbase_itemcategory` VALUES (2,'{\"ar\": \"\\u062a\\u0630\\u0627\\u0643\\u0631\", \"da\": \"Billetter\", \"de\": \"Tickets\", \"de-informal\": \"Tickets\", \"el\": \"\\u0395\\u03b9\\u03c3\\u03b9\\u03c4\\u03ae\\u03c1\\u03b9\\u03b1\", \"en\": \"Tickets\", \"es\": \"Tickets\", \"fr\": \"Tickets\", \"lv\": \"Tickets\", \"nl\": \"Tickets\", \"nl-informal\": \"Kaartjes\", \"ru\": \"Tickets\", \"tr\": \"Biletler\", \"zh-hans\": \"\\u7968\"}',0,4,'',0,NULL);
/*!40000 ALTER TABLE `pretixbase_itemcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_itemvariation`
--

DROP TABLE IF EXISTS `pretixbase_itemvariation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_itemvariation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` longtext NOT NULL,
  `active` tinyint(1) NOT NULL,
  `position` int(10) unsigned NOT NULL,
  `default_price` decimal(7,2) DEFAULT NULL,
  `item_id` int(11) NOT NULL,
  `description` longtext DEFAULT NULL,
  `original_price` decimal(7,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_itemvariation_item_id_e3d28791_fk_pretixbase_item_id` (`item_id`),
  CONSTRAINT `pretixbase_itemvariation_item_id_e3d28791_fk_pretixbase_item_id` FOREIGN KEY (`item_id`) REFERENCES `pretixbase_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_itemvariation`
--

LOCK TABLES `pretixbase_itemvariation` WRITE;
/*!40000 ALTER TABLE `pretixbase_itemvariation` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_itemvariation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_logentry`
--

DROP TABLE IF EXISTS `pretixbase_logentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_logentry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(10) unsigned NOT NULL,
  `datetime` datetime(6) NOT NULL,
  `action_type` varchar(255) NOT NULL,
  `data` longtext NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `api_token_id` int(11) DEFAULT NULL,
  `visible` tinyint(1) NOT NULL,
  `shredded` tinyint(1) NOT NULL,
  `oauth_application_id` bigint(20) DEFAULT NULL,
  `device_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_logentry_datetime_60ff2d52` (`datetime`),
  KEY `pretixbase_logentry_object_id_f43ba680` (`object_id`),
  KEY `pretixbase_logentry_content_type_id_f187b95a_fk_django_co` (`content_type_id`),
  KEY `pretixbase_logentry_user_id_ba1c5649_fk_pretixbase_user_id` (`user_id`),
  KEY `pretixbase_logentry_api_token_id_e439bab1_fk_pretixbas` (`api_token_id`),
  KEY `pretixbase_logentry_event_id_3a3653c2_fk_pretixbase_event_id` (`event_id`),
  KEY `pretixbase_logentry_oauth_application_id_1494edd6_fk_pretixapi` (`oauth_application_id`),
  KEY `pretixbase_logentry_device_id_de073446_fk_pretixbase_device_id` (`device_id`),
  CONSTRAINT `pretixbase_logentry_api_token_id_e439bab1_fk_pretixbas` FOREIGN KEY (`api_token_id`) REFERENCES `pretixbase_teamapitoken` (`id`),
  CONSTRAINT `pretixbase_logentry_content_type_id_f187b95a_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `pretixbase_logentry_device_id_de073446_fk_pretixbase_device_id` FOREIGN KEY (`device_id`) REFERENCES `pretixbase_device` (`id`),
  CONSTRAINT `pretixbase_logentry_event_id_3a3653c2_fk_pretixbase_event_id` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `pretixbase_logentry_oauth_application_id_1494edd6_fk_pretixapi` FOREIGN KEY (`oauth_application_id`) REFERENCES `pretixapi_oauthapplication` (`id`),
  CONSTRAINT `pretixbase_logentry_user_id_ba1c5649_fk_pretixbase_user_id` FOREIGN KEY (`user_id`) REFERENCES `pretixbase_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_logentry`
--

LOCK TABLES `pretixbase_logentry` WRITE;
/*!40000 ALTER TABLE `pretixbase_logentry` DISABLE KEYS */;
INSERT INTO `pretixbase_logentry` VALUES (1,2,'2020-02-18 17:36:40.016828','pretix.team.created','{\"all_events\": true, \"can_change_event_settings\": true, \"can_change_items\": true, \"can_change_organizer_settings\": true, \"can_change_teams\": true, \"can_create_events\": true, \"can_view_orders\": true, \"name\": \"hoeringsportal\"}',35,NULL,1,NULL,1,0,NULL,NULL),(2,2,'2020-02-18 17:37:17.174659','pretix.team.token.created','{\"id\": 1, \"name\": \"hoeringsportal\"}',35,NULL,1,NULL,1,0,NULL,NULL),(3,1,'2020-02-26 08:35:55.985353','pretix.event.settings','{\"currency\": \"DKK\", \"date_from\": \"2001-01-01T00:00:00Z\", \"date_to\": null, \"geo_lat\": null, \"geo_lon\": null, \"has_subevents\": false, \"locale\": \"en\", \"locales\": [\"en\"], \"location\": {\"ar\": \"\", \"da\": \"\", \"de\": \"\", \"de-informal\": \"\", \"el\": \"\", \"en\": \"\", \"es\": \"\", \"fr\": \"\", \"lv\": \"\", \"nl\": \"\", \"nl-informal\": \"\", \"ru\": \"\", \"tr\": \"\", \"zh-hans\": \"\"}, \"name\": {\"ar\": \"\", \"da\": \"\", \"de\": \"\", \"de-informal\": \"\", \"el\": \"\", \"en\": \"Template (series)\", \"es\": \"\", \"fr\": \"\", \"lv\": \"\", \"nl\": \"\", \"nl-informal\": \"\", \"ru\": \"\", \"tr\": \"\", \"zh-hans\": \"\"}, \"organizer\": {\"id\": 1, \"type\": \"Organizer\"}, \"presale_end\": null, \"presale_start\": null, \"slug\": \"template-series\", \"tax_rate\": null, \"timezone\": \"UTC\"}',9,NULL,1,NULL,1,0,NULL,NULL),(4,1,'2020-02-26 08:36:08.019971','pretix.event.plugins.enabled','{\"plugin\": \"pretix.plugins.ticketoutputpdf\"}',9,NULL,1,NULL,1,0,NULL,NULL),(5,1,'2020-02-26 08:36:08.034573','pretix.event.settings','{}',9,NULL,1,NULL,1,0,NULL,NULL),(6,1,'2020-02-26 08:36:08.204268','pretix.event.category.added','{\"name\": \"Tickets\"}',12,NULL,1,NULL,1,0,NULL,NULL),(7,1,'2020-02-26 08:36:08.213303','pretix.event.item.added','{\"DELETE\": false, \"default_price\": \"35\", \"name\": {\"ar\": \"\", \"da\": \"\", \"de\": \"\", \"de-informal\": \"\", \"el\": \"\", \"en\": \"Regular ticket\", \"es\": \"\", \"fr\": \"\", \"lv\": \"\", \"nl\": \"\", \"nl-informal\": \"\", \"ru\": \"\", \"tr\": \"\", \"zh-hans\": \"\"}, \"quota\": 100}',11,NULL,1,NULL,1,0,NULL,NULL),(8,1,'2020-02-26 08:36:08.217726','pretix.event.quota.added','{\"DELETE\": false, \"default_price\": \"35\", \"name\": {\"ar\": \"\", \"da\": \"\", \"de\": \"\", \"de-informal\": \"\", \"el\": \"\", \"en\": \"Regular ticket\", \"es\": \"\", \"fr\": \"\", \"lv\": \"\", \"nl\": \"\", \"nl-informal\": \"\", \"ru\": \"\", \"tr\": \"\", \"zh-hans\": \"\"}, \"quota\": 100}',20,NULL,1,NULL,1,0,NULL,NULL),(9,2,'2020-02-26 08:36:08.227094','pretix.event.item.added','{\"DELETE\": false, \"default_price\": \"29.00\", \"name\": {\"ar\": \"\", \"da\": \"\", \"de\": \"\", \"de-informal\": \"\", \"el\": \"\", \"en\": \"Reduced ticket\", \"es\": \"\", \"fr\": \"\", \"lv\": \"\", \"nl\": \"\", \"nl-informal\": \"\", \"ru\": \"\", \"tr\": \"\", \"zh-hans\": \"\"}, \"quota\": 50}',11,NULL,1,NULL,1,0,NULL,NULL),(10,2,'2020-02-26 08:36:08.230855','pretix.event.quota.added','{\"DELETE\": false, \"default_price\": \"29.00\", \"name\": {\"ar\": \"\", \"da\": \"\", \"de\": \"\", \"de-informal\": \"\", \"el\": \"\", \"en\": \"Reduced ticket\", \"es\": \"\", \"fr\": \"\", \"lv\": \"\", \"nl\": \"\", \"nl-informal\": \"\", \"ru\": \"\", \"tr\": \"\", \"zh-hans\": \"\"}, \"quota\": 50}',20,NULL,1,NULL,1,0,NULL,NULL),(11,1,'2020-02-26 08:40:59.508437','pretix.event.deleted','{\"event_id\": 1, \"logentries\": [10, 9, 8, 7, 6, 5, 4, 3], \"name\": \"Template (series)\"}',17,NULL,1,NULL,1,0,NULL,NULL),(12,2,'2020-02-26 08:41:39.280302','pretix.event.settings','{\"currency\": \"DKK\", \"date_from\": \"2001-01-01T00:00:00Z\", \"date_to\": null, \"geo_lat\": null, \"geo_lon\": null, \"has_subevents\": false, \"locale\": \"en\", \"locales\": [\"en\", \"da\"], \"location\": {\"ar\": \"\", \"da\": \"\", \"de\": \"\", \"de-informal\": \"\", \"el\": \"\", \"en\": \"\", \"es\": \"\", \"fr\": \"\", \"lv\": \"\", \"nl\": \"\", \"nl-informal\": \"\", \"ru\": \"\", \"tr\": \"\", \"zh-hans\": \"\"}, \"name\": {\"ar\": \"\", \"da\": \"Skabelon (serie)\", \"de\": \"\", \"de-informal\": \"\", \"el\": \"\", \"en\": \"Template (series)\", \"es\": \"\", \"fr\": \"\", \"lv\": \"\", \"nl\": \"\", \"nl-informal\": \"\", \"ru\": \"\", \"tr\": \"\", \"zh-hans\": \"\"}, \"organizer\": {\"id\": 1, \"type\": \"Organizer\"}, \"presale_end\": null, \"presale_start\": null, \"slug\": \"template-series\", \"tax_rate\": null, \"timezone\": \"UTC\"}',9,NULL,1,NULL,1,0,NULL,NULL),(13,1,'2020-02-26 08:41:54.451913','pretix.event.deleted','{\"event_id\": 2, \"logentries\": [12], \"name\": \"Template (series)\"}',17,NULL,1,NULL,1,0,NULL,NULL),(14,3,'2020-02-26 08:42:13.481426','pretix.event.settings','{\"currency\": \"DKK\", \"date_from\": \"2001-01-01T00:00:00Z\", \"date_to\": null, \"geo_lat\": null, \"geo_lon\": null, \"has_subevents\": true, \"locale\": \"en\", \"locales\": [\"en\", \"da\"], \"location\": {\"ar\": \"\", \"da\": \"\", \"de\": \"\", \"de-informal\": \"\", \"el\": \"\", \"en\": \"\", \"es\": \"\", \"fr\": \"\", \"lv\": \"\", \"nl\": \"\", \"nl-informal\": \"\", \"ru\": \"\", \"tr\": \"\", \"zh-hans\": \"\"}, \"name\": {\"ar\": \"\", \"da\": \"Skabelon (serie)\", \"de\": \"\", \"de-informal\": \"\", \"el\": \"\", \"en\": \"Template (series)\", \"es\": \"\", \"fr\": \"\", \"lv\": \"\", \"nl\": \"\", \"nl-informal\": \"\", \"ru\": \"\", \"tr\": \"\", \"zh-hans\": \"\"}, \"organizer\": {\"id\": 1, \"type\": \"Organizer\"}, \"presale_end\": null, \"presale_start\": null, \"slug\": \"template-series\", \"tax_rate\": null, \"timezone\": \"UTC\"}',9,3,1,NULL,1,0,NULL,NULL),(15,3,'2020-02-26 08:42:31.367564','pretix.event.item.added','{\"default_price\": \"0\", \"name\": {\"ar\": \"\", \"da\": \"Billet\", \"de\": \"\", \"de-informal\": \"\", \"el\": \"\", \"en\": \"Ticket\", \"es\": \"\", \"fr\": \"\", \"lv\": \"\", \"nl\": \"\", \"nl-informal\": \"\", \"ru\": \"\", \"tr\": \"\", \"zh-hans\": \"\"}}',11,3,1,NULL,1,0,NULL,NULL),(16,3,'2020-02-26 08:42:49.534055','pretix.event.quota.added','{\"close_when_sold_out\": false, \"itemvars\": [\"3\"], \"name\": \"Tickets\", \"size\": 0, \"subevent\": {\"id\": 1, \"type\": \"SubEvent\"}}',20,3,1,NULL,1,0,NULL,NULL),(17,4,'2020-02-26 08:43:24.252561','pretix.event.settings','{\"copy_from_event\": null, \"currency\": \"DKK\", \"date_from\": \"2001-01-01T00:00:00Z\", \"date_to\": null, \"geo_lat\": null, \"geo_lon\": null, \"has_subevents\": false, \"locale\": \"en\", \"locales\": [\"en\", \"da\"], \"location\": {\"ar\": \"\", \"da\": \"\", \"de\": \"\", \"de-informal\": \"\", \"el\": \"\", \"en\": \"\", \"es\": \"\", \"fr\": \"\", \"lv\": \"\", \"nl\": \"\", \"nl-informal\": \"\", \"ru\": \"\", \"tr\": \"\", \"zh-hans\": \"\"}, \"name\": {\"ar\": \"\", \"da\": \"Skabelon (enkeltst\\u00e5ende)\", \"de\": \"\", \"de-informal\": \"\", \"el\": \"\", \"en\": \"Template (single)\", \"es\": \"\", \"fr\": \"\", \"lv\": \"\", \"nl\": \"\", \"nl-informal\": \"\", \"ru\": \"\", \"tr\": \"\", \"zh-hans\": \"\"}, \"organizer\": {\"id\": 1, \"type\": \"Organizer\"}, \"presale_end\": null, \"presale_start\": null, \"slug\": \"template-single\", \"tax_rate\": null, \"timezone\": \"UTC\"}',9,4,1,NULL,1,0,NULL,NULL),(18,4,'2020-02-26 08:43:41.885258','pretix.event.plugins.enabled','{\"plugin\": \"pretix.plugins.ticketoutputpdf\"}',9,4,1,NULL,1,0,NULL,NULL),(19,4,'2020-02-26 08:43:41.895709','pretix.event.settings','{}',9,4,1,NULL,1,0,NULL,NULL),(20,2,'2020-02-26 08:43:41.901944','pretix.event.category.added','{\"name\": \"Tickets\"}',12,4,1,NULL,1,0,NULL,NULL),(21,4,'2020-02-26 08:43:41.910891','pretix.event.item.added','{\"DELETE\": false, \"default_price\": \"0\", \"name\": {\"ar\": \"\", \"da\": \"Billet\", \"de\": \"\", \"de-informal\": \"\", \"el\": \"\", \"en\": \"Ticket\", \"es\": \"\", \"fr\": \"\", \"lv\": \"\", \"nl\": \"\", \"nl-informal\": \"\", \"ru\": \"\", \"tr\": \"\", \"zh-hans\": \"\"}, \"quota\": 0}',11,4,1,NULL,1,0,NULL,NULL),(22,4,'2020-02-26 08:43:41.913525','pretix.event.quota.added','{\"DELETE\": false, \"default_price\": \"0\", \"name\": {\"ar\": \"\", \"da\": \"Billet\", \"de\": \"\", \"de-informal\": \"\", \"el\": \"\", \"en\": \"Ticket\", \"es\": \"\", \"fr\": \"\", \"lv\": \"\", \"nl\": \"\", \"nl-informal\": \"\", \"ru\": \"\", \"tr\": \"\", \"zh-hans\": \"\"}, \"quota\": 0}',20,4,1,NULL,1,0,NULL,NULL);
/*!40000 ALTER TABLE `pretixbase_logentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_notificationsetting`
--

DROP TABLE IF EXISTS `pretixbase_notificationsetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_notificationsetting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_type` varchar(255) NOT NULL,
  `method` varchar(255) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_notifications_user_id_action_type_even_8efd2fd1_uniq` (`user_id`,`action_type`,`event_id`,`method`),
  KEY `pretixbase_notificat_event_id_f0fd9901_fk_pretixbas` (`event_id`),
  CONSTRAINT `pretixbase_notificat_event_id_f0fd9901_fk_pretixbas` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `pretixbase_notificat_user_id_c493b5ba_fk_pretixbas` FOREIGN KEY (`user_id`) REFERENCES `pretixbase_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_notificationsetting`
--

LOCK TABLES `pretixbase_notificationsetting` WRITE;
/*!40000 ALTER TABLE `pretixbase_notificationsetting` DISABLE KEYS */;
INSERT INTO `pretixbase_notificationsetting` VALUES (1,'pretix.event.order.refund.requested','mail',NULL,1,1);
/*!40000 ALTER TABLE `pretixbase_notificationsetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_order`
--

DROP TABLE IF EXISTS `pretixbase_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(16) NOT NULL,
  `status` varchar(3) NOT NULL,
  `email` varchar(254) DEFAULT NULL,
  `locale` varchar(32) DEFAULT NULL,
  `secret` varchar(32) NOT NULL,
  `datetime` datetime(6) NOT NULL,
  `expires` datetime(6) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `event_id` int(11) NOT NULL,
  `comment` longtext NOT NULL,
  `expiry_reminder_sent` tinyint(1) NOT NULL,
  `meta_info` longtext DEFAULT NULL,
  `download_reminder_sent` tinyint(1) NOT NULL,
  `checkin_attention` tinyint(1) NOT NULL,
  `last_modified` datetime(6) NOT NULL,
  `require_approval` tinyint(1) NOT NULL,
  `sales_channel` varchar(190) NOT NULL,
  `testmode` tinyint(1) NOT NULL,
  `email_known_to_work` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_order_code_1a5b4b96` (`code`),
  KEY `pretixbase_order_status_48db4c28` (`status`),
  KEY `pretixbase_order_event_id_fcc6f9c6_fk_pretixbase_event_id` (`event_id`),
  KEY `pretixbase_order_last_modified_30e4a7b2` (`last_modified`),
  KEY `pretixbase_order_datetime_b588c1be` (`datetime`),
  CONSTRAINT `pretixbase_order_event_id_fcc6f9c6_fk_pretixbase_event_id` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_order`
--

LOCK TABLES `pretixbase_order` WRITE;
/*!40000 ALTER TABLE `pretixbase_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_orderfee`
--

DROP TABLE IF EXISTS `pretixbase_orderfee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_orderfee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` decimal(10,2) NOT NULL,
  `description` varchar(190) NOT NULL,
  `internal_type` varchar(255) NOT NULL,
  `fee_type` varchar(100) NOT NULL,
  `tax_rate` decimal(7,2) NOT NULL,
  `tax_value` decimal(10,2) NOT NULL,
  `order_id` int(11) NOT NULL,
  `tax_rule_id` int(11) DEFAULT NULL,
  `canceled` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_orderfee_tax_rule_id_082755a4_fk_pretixbas` (`tax_rule_id`),
  KEY `pretixbase_orderfee_order_id_b8c4a186_fk_pretixbase_order_id` (`order_id`),
  CONSTRAINT `pretixbase_orderfee_order_id_b8c4a186_fk_pretixbase_order_id` FOREIGN KEY (`order_id`) REFERENCES `pretixbase_order` (`id`),
  CONSTRAINT `pretixbase_orderfee_tax_rule_id_082755a4_fk_pretixbas` FOREIGN KEY (`tax_rule_id`) REFERENCES `pretixbase_taxrule` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_orderfee`
--

LOCK TABLES `pretixbase_orderfee` WRITE;
/*!40000 ALTER TABLE `pretixbase_orderfee` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_orderfee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_orderpayment`
--

DROP TABLE IF EXISTS `pretixbase_orderpayment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_orderpayment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `local_id` int(10) unsigned NOT NULL,
  `state` varchar(190) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created` datetime(6) NOT NULL,
  `payment_date` datetime(6) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `info` longtext DEFAULT NULL,
  `migrated` tinyint(1) NOT NULL,
  `fee_id` int(11) DEFAULT NULL,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_orderpayment_order_id_80a5e1fb_fk_pretixbase_order_id` (`order_id`),
  KEY `pretixbase_orderpaym_fee_id_392fba8e_fk_pretixbas` (`fee_id`),
  CONSTRAINT `pretixbase_orderpaym_fee_id_392fba8e_fk_pretixbas` FOREIGN KEY (`fee_id`) REFERENCES `pretixbase_orderfee` (`id`),
  CONSTRAINT `pretixbase_orderpayment_order_id_80a5e1fb_fk_pretixbase_order_id` FOREIGN KEY (`order_id`) REFERENCES `pretixbase_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_orderpayment`
--

LOCK TABLES `pretixbase_orderpayment` WRITE;
/*!40000 ALTER TABLE `pretixbase_orderpayment` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_orderpayment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_orderposition`
--

DROP TABLE IF EXISTS `pretixbase_orderposition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_orderposition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` decimal(10,2) NOT NULL,
  `attendee_name_cached` varchar(255) DEFAULT NULL,
  `item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `variation_id` int(11) DEFAULT NULL,
  `voucher_id` int(11) DEFAULT NULL,
  `tax_rate` decimal(7,2) NOT NULL,
  `tax_value` decimal(10,2) NOT NULL,
  `secret` varchar(64) NOT NULL,
  `positionid` int(10) unsigned NOT NULL,
  `attendee_email` varchar(254) DEFAULT NULL,
  `addon_to_id` int(11) DEFAULT NULL,
  `meta_info` longtext DEFAULT NULL,
  `subevent_id` int(11) DEFAULT NULL,
  `tax_rule_id` int(11) DEFAULT NULL,
  `pseudonymization_id` varchar(16) NOT NULL,
  `attendee_name_parts` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `canceled` tinyint(1) NOT NULL,
  `web_secret` varchar(32) NOT NULL,
  `seat_id` int(11) DEFAULT NULL,
  `price_before_voucher` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pseudonymization_id` (`pseudonymization_id`),
  KEY `pretixbase_orderposition_item_id_6eb5dffe_fk_pretixbase_item_id` (`item_id`),
  KEY `pretixbase_orderposi_variation_id_04605fc4_fk_pretixbas` (`variation_id`),
  KEY `pretixbase_orderposition_secret_ecd577f1` (`secret`),
  KEY `pretixbase_orderposi_tax_rule_id_6564b2f1_fk_pretixbas` (`tax_rule_id`),
  KEY `pretixbase_orderposi_order_id_0d44232b_fk_pretixbas` (`order_id`),
  KEY `pretixbase_orderposi_addon_to_id_480d4760_fk_pretixbas` (`addon_to_id`),
  KEY `pretixbase_orderposi_subevent_id_b1dda9a0_fk_pretixbas` (`subevent_id`),
  KEY `pretixbase_orderposi_voucher_id_e1ed13ae_fk_pretixbas` (`voucher_id`),
  KEY `pretixbase_orderposition_web_secret_7b80edd8` (`web_secret`),
  KEY `pretixbase_orderposition_seat_id_37ad0d08_fk_pretixbase_seat_id` (`seat_id`),
  CONSTRAINT `pretixbase_orderposi_addon_to_id_480d4760_fk_pretixbas` FOREIGN KEY (`addon_to_id`) REFERENCES `pretixbase_orderposition` (`id`),
  CONSTRAINT `pretixbase_orderposi_order_id_0d44232b_fk_pretixbas` FOREIGN KEY (`order_id`) REFERENCES `pretixbase_order` (`id`),
  CONSTRAINT `pretixbase_orderposi_subevent_id_b1dda9a0_fk_pretixbas` FOREIGN KEY (`subevent_id`) REFERENCES `pretixbase_subevent` (`id`),
  CONSTRAINT `pretixbase_orderposi_tax_rule_id_6564b2f1_fk_pretixbas` FOREIGN KEY (`tax_rule_id`) REFERENCES `pretixbase_taxrule` (`id`),
  CONSTRAINT `pretixbase_orderposi_variation_id_04605fc4_fk_pretixbas` FOREIGN KEY (`variation_id`) REFERENCES `pretixbase_itemvariation` (`id`),
  CONSTRAINT `pretixbase_orderposi_voucher_id_e1ed13ae_fk_pretixbas` FOREIGN KEY (`voucher_id`) REFERENCES `pretixbase_voucher` (`id`),
  CONSTRAINT `pretixbase_orderposition_item_id_6eb5dffe_fk_pretixbase_item_id` FOREIGN KEY (`item_id`) REFERENCES `pretixbase_item` (`id`),
  CONSTRAINT `pretixbase_orderposition_seat_id_37ad0d08_fk_pretixbase_seat_id` FOREIGN KEY (`seat_id`) REFERENCES `pretixbase_seat` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_orderposition`
--

LOCK TABLES `pretixbase_orderposition` WRITE;
/*!40000 ALTER TABLE `pretixbase_orderposition` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_orderposition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_orderrefund`
--

DROP TABLE IF EXISTS `pretixbase_orderrefund`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_orderrefund` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `local_id` int(10) unsigned NOT NULL,
  `state` varchar(190) NOT NULL,
  `source` varchar(190) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created` datetime(6) NOT NULL,
  `execution_date` datetime(6) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `info` longtext DEFAULT NULL,
  `order_id` int(11) NOT NULL,
  `payment_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_orderrefund_order_id_029acd4f_fk_pretixbase_order_id` (`order_id`),
  KEY `pretixbase_orderrefu_payment_id_9476c326_fk_pretixbas` (`payment_id`),
  CONSTRAINT `pretixbase_orderrefu_payment_id_9476c326_fk_pretixbas` FOREIGN KEY (`payment_id`) REFERENCES `pretixbase_orderpayment` (`id`),
  CONSTRAINT `pretixbase_orderrefund_order_id_029acd4f_fk_pretixbase_order_id` FOREIGN KEY (`order_id`) REFERENCES `pretixbase_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_orderrefund`
--

LOCK TABLES `pretixbase_orderrefund` WRITE;
/*!40000 ALTER TABLE `pretixbase_orderrefund` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_orderrefund` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_organizer`
--

DROP TABLE IF EXISTS `pretixbase_organizer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_organizer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `slug` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_organizer_slug_8ef8a925_uniq` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_organizer`
--

LOCK TABLES `pretixbase_organizer` WRITE;
/*!40000 ALTER TABLE `pretixbase_organizer` DISABLE KEYS */;
INSERT INTO `pretixbase_organizer` VALUES (1,'hoeringsportal','hoeringsportal');
/*!40000 ALTER TABLE `pretixbase_organizer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_organizer_settingsstore`
--

DROP TABLE IF EXISTS `pretixbase_organizer_settingsstore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_organizer_settingsstore` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` longtext NOT NULL,
  `object_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_organizer_object_id_b55adabf_fk_pretixbas` (`object_id`),
  CONSTRAINT `pretixbase_organizer_object_id_b55adabf_fk_pretixbas` FOREIGN KEY (`object_id`) REFERENCES `pretixbase_organizer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_organizer_settingsstore`
--

LOCK TABLES `pretixbase_organizer_settingsstore` WRITE;
/*!40000 ALTER TABLE `pretixbase_organizer_settingsstore` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_organizer_settingsstore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_question`
--

DROP TABLE IF EXISTS `pretixbase_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` longtext NOT NULL,
  `type` varchar(5) NOT NULL,
  `required` tinyint(1) NOT NULL,
  `event_id` int(11) NOT NULL,
  `position` int(10) unsigned NOT NULL,
  `help_text` longtext DEFAULT NULL,
  `ask_during_checkin` tinyint(1) NOT NULL,
  `identifier` varchar(190) NOT NULL,
  `dependency_question_id` int(11) DEFAULT NULL,
  `dependency_values` longtext NOT NULL,
  `hidden` tinyint(1) NOT NULL,
  `print_on_invoice` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_question_event_id_ca103445_fk_pretixbase_event_id` (`event_id`),
  KEY `pretixbase_question_dependency_question__a02199c8_fk_pretixbas` (`dependency_question_id`),
  CONSTRAINT `pretixbase_question_dependency_question__a02199c8_fk_pretixbas` FOREIGN KEY (`dependency_question_id`) REFERENCES `pretixbase_question` (`id`),
  CONSTRAINT `pretixbase_question_event_id_ca103445_fk_pretixbase_event_id` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_question`
--

LOCK TABLES `pretixbase_question` WRITE;
/*!40000 ALTER TABLE `pretixbase_question` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_question_items`
--

DROP TABLE IF EXISTS `pretixbase_question_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_question_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_question_items_question_id_item_id_ff34e83a_uniq` (`question_id`,`item_id`),
  KEY `pretixbase_question_items_item_id_ceeaebc0_fk_pretixbase_item_id` (`item_id`),
  CONSTRAINT `pretixbase_question__question_id_fc7dc2f8_fk_pretixbas` FOREIGN KEY (`question_id`) REFERENCES `pretixbase_question` (`id`),
  CONSTRAINT `pretixbase_question_items_item_id_ceeaebc0_fk_pretixbase_item_id` FOREIGN KEY (`item_id`) REFERENCES `pretixbase_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_question_items`
--

LOCK TABLES `pretixbase_question_items` WRITE;
/*!40000 ALTER TABLE `pretixbase_question_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_question_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_questionanswer`
--

DROP TABLE IF EXISTS `pretixbase_questionanswer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_questionanswer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `answer` longtext NOT NULL,
  `cartposition_id` int(11) DEFAULT NULL,
  `orderposition_id` int(11) DEFAULT NULL,
  `question_id` int(11) NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_questiona_cartposition_id_de73bb5f_fk_pretixbas` (`cartposition_id`),
  KEY `pretixbase_questiona_orderposition_id_1ccb6977_fk_pretixbas` (`orderposition_id`),
  KEY `pretixbase_questiona_question_id_9a80a111_fk_pretixbas` (`question_id`),
  CONSTRAINT `pretixbase_questiona_cartposition_id_de73bb5f_fk_pretixbas` FOREIGN KEY (`cartposition_id`) REFERENCES `pretixbase_cartposition` (`id`),
  CONSTRAINT `pretixbase_questiona_orderposition_id_1ccb6977_fk_pretixbas` FOREIGN KEY (`orderposition_id`) REFERENCES `pretixbase_orderposition` (`id`),
  CONSTRAINT `pretixbase_questiona_question_id_9a80a111_fk_pretixbas` FOREIGN KEY (`question_id`) REFERENCES `pretixbase_question` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_questionanswer`
--

LOCK TABLES `pretixbase_questionanswer` WRITE;
/*!40000 ALTER TABLE `pretixbase_questionanswer` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_questionanswer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_questionanswer_options`
--

DROP TABLE IF EXISTS `pretixbase_questionanswer_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_questionanswer_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `questionanswer_id` int(11) NOT NULL,
  `questionoption_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_questionanswe_questionanswer_id_questi_8749a3d3_uniq` (`questionanswer_id`,`questionoption_id`),
  KEY `pretixbase_questiona_questionoption_id_641ff2f6_fk_pretixbas` (`questionoption_id`),
  CONSTRAINT `pretixbase_questiona_questionanswer_id_21ac63b6_fk_pretixbas` FOREIGN KEY (`questionanswer_id`) REFERENCES `pretixbase_questionanswer` (`id`),
  CONSTRAINT `pretixbase_questiona_questionoption_id_641ff2f6_fk_pretixbas` FOREIGN KEY (`questionoption_id`) REFERENCES `pretixbase_questionoption` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_questionanswer_options`
--

LOCK TABLES `pretixbase_questionanswer_options` WRITE;
/*!40000 ALTER TABLE `pretixbase_questionanswer_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_questionanswer_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_questionoption`
--

DROP TABLE IF EXISTS `pretixbase_questionoption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_questionoption` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `answer` longtext NOT NULL,
  `question_id` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `identifier` varchar(190) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_questiono_question_id_67c888dd_fk_pretixbas` (`question_id`),
  CONSTRAINT `pretixbase_questiono_question_id_67c888dd_fk_pretixbas` FOREIGN KEY (`question_id`) REFERENCES `pretixbase_question` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_questionoption`
--

LOCK TABLES `pretixbase_questionoption` WRITE;
/*!40000 ALTER TABLE `pretixbase_questionoption` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_questionoption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_quota`
--

DROP TABLE IF EXISTS `pretixbase_quota`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_quota` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `size` int(10) unsigned DEFAULT NULL,
  `event_id` int(11) NOT NULL,
  `subevent_id` int(11) DEFAULT NULL,
  `cached_availability_number` int(10) unsigned DEFAULT NULL,
  `cached_availability_state` int(10) unsigned DEFAULT NULL,
  `cached_availability_time` datetime(6) DEFAULT NULL,
  `cached_availability_paid_orders` int(10) unsigned DEFAULT NULL,
  `close_when_sold_out` tinyint(1) NOT NULL,
  `closed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_quota_event_id_e57269de_fk_pretixbase_event_id` (`event_id`),
  KEY `pretixbase_quota_subevent_id_f2fc62f2_fk_pretixbase_subevent_id` (`subevent_id`),
  CONSTRAINT `pretixbase_quota_event_id_e57269de_fk_pretixbase_event_id` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `pretixbase_quota_subevent_id_f2fc62f2_fk_pretixbase_subevent_id` FOREIGN KEY (`subevent_id`) REFERENCES `pretixbase_subevent` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_quota`
--

LOCK TABLES `pretixbase_quota` WRITE;
/*!40000 ALTER TABLE `pretixbase_quota` DISABLE KEYS */;
INSERT INTO `pretixbase_quota` VALUES (3,'Tickets',0,3,1,0,0,'2020-02-26 08:42:49.630868',0,0,0),(4,'Ticket',0,4,NULL,0,0,'2020-02-26 08:43:42.186251',0,0,0);
/*!40000 ALTER TABLE `pretixbase_quota` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_quota_items`
--

DROP TABLE IF EXISTS `pretixbase_quota_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_quota_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quota_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_quota_items_quota_id_item_id_577011c3_uniq` (`quota_id`,`item_id`),
  KEY `pretixbase_quota_items_item_id_f7234603_fk_pretixbase_item_id` (`item_id`),
  CONSTRAINT `pretixbase_quota_items_item_id_f7234603_fk_pretixbase_item_id` FOREIGN KEY (`item_id`) REFERENCES `pretixbase_item` (`id`),
  CONSTRAINT `pretixbase_quota_items_quota_id_222bf960_fk_pretixbase_quota_id` FOREIGN KEY (`quota_id`) REFERENCES `pretixbase_quota` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_quota_items`
--

LOCK TABLES `pretixbase_quota_items` WRITE;
/*!40000 ALTER TABLE `pretixbase_quota_items` DISABLE KEYS */;
INSERT INTO `pretixbase_quota_items` VALUES (3,3,3),(4,4,4);
/*!40000 ALTER TABLE `pretixbase_quota_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_quota_variations`
--

DROP TABLE IF EXISTS `pretixbase_quota_variations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_quota_variations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quota_id` int(11) NOT NULL,
  `itemvariation_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_quota_variati_quota_id_itemvariation_i_0dfadf28_uniq` (`quota_id`,`itemvariation_id`),
  KEY `pretixbase_quota_var_itemvariation_id_c3ea6748_fk_pretixbas` (`itemvariation_id`),
  CONSTRAINT `pretixbase_quota_var_itemvariation_id_c3ea6748_fk_pretixbas` FOREIGN KEY (`itemvariation_id`) REFERENCES `pretixbase_itemvariation` (`id`),
  CONSTRAINT `pretixbase_quota_var_quota_id_73db970d_fk_pretixbas` FOREIGN KEY (`quota_id`) REFERENCES `pretixbase_quota` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_quota_variations`
--

LOCK TABLES `pretixbase_quota_variations` WRITE;
/*!40000 ALTER TABLE `pretixbase_quota_variations` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_quota_variations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_requiredaction`
--

DROP TABLE IF EXISTS `pretixbase_requiredaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_requiredaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime(6) NOT NULL,
  `done` tinyint(1) NOT NULL,
  `action_type` varchar(255) NOT NULL,
  `data` longtext NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_requiredaction_datetime_517349c7` (`datetime`),
  KEY `pretixbase_requireda_event_id_613933ef_fk_pretixbas` (`event_id`),
  KEY `pretixbase_requiredaction_user_id_256866db_fk_pretixbase_user_id` (`user_id`),
  CONSTRAINT `pretixbase_requireda_event_id_613933ef_fk_pretixbas` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `pretixbase_requiredaction_user_id_256866db_fk_pretixbase_user_id` FOREIGN KEY (`user_id`) REFERENCES `pretixbase_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_requiredaction`
--

LOCK TABLES `pretixbase_requiredaction` WRITE;
/*!40000 ALTER TABLE `pretixbase_requiredaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_requiredaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_seat`
--

DROP TABLE IF EXISTS `pretixbase_seat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_seat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(190) NOT NULL,
  `blocked` tinyint(1) NOT NULL,
  `event_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `subevent_id` int(11) DEFAULT NULL,
  `seat_guid` varchar(190) NOT NULL,
  `row_name` varchar(190) NOT NULL,
  `seat_number` varchar(190) NOT NULL,
  `zone_name` varchar(190) NOT NULL,
  `sorting_rank` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_seat_event_id_9a773a14_fk_pretixbase_event_id` (`event_id`),
  KEY `pretixbase_seat_product_id_73407f46_fk_pretixbase_item_id` (`product_id`),
  KEY `pretixbase_seat_subevent_id_278a2c92_fk_pretixbase_subevent_id` (`subevent_id`),
  KEY `pretixbase_seat_seat_guid_ad022115` (`seat_guid`),
  CONSTRAINT `pretixbase_seat_event_id_9a773a14_fk_pretixbase_event_id` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `pretixbase_seat_product_id_73407f46_fk_pretixbase_item_id` FOREIGN KEY (`product_id`) REFERENCES `pretixbase_item` (`id`),
  CONSTRAINT `pretixbase_seat_subevent_id_278a2c92_fk_pretixbase_subevent_id` FOREIGN KEY (`subevent_id`) REFERENCES `pretixbase_subevent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_seat`
--

LOCK TABLES `pretixbase_seat` WRITE;
/*!40000 ALTER TABLE `pretixbase_seat` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_seat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_seatcategorymapping`
--

DROP TABLE IF EXISTS `pretixbase_seatcategorymapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_seatcategorymapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layout_category` varchar(190) NOT NULL,
  `event_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `subevent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_seatcateg_event_id_f3de411f_fk_pretixbas` (`event_id`),
  KEY `pretixbase_seatcateg_product_id_22916f47_fk_pretixbas` (`product_id`),
  KEY `pretixbase_seatcateg_subevent_id_e0f8e643_fk_pretixbas` (`subevent_id`),
  CONSTRAINT `pretixbase_seatcateg_event_id_f3de411f_fk_pretixbas` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `pretixbase_seatcateg_product_id_22916f47_fk_pretixbas` FOREIGN KEY (`product_id`) REFERENCES `pretixbase_item` (`id`),
  CONSTRAINT `pretixbase_seatcateg_subevent_id_e0f8e643_fk_pretixbas` FOREIGN KEY (`subevent_id`) REFERENCES `pretixbase_subevent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_seatcategorymapping`
--

LOCK TABLES `pretixbase_seatcategorymapping` WRITE;
/*!40000 ALTER TABLE `pretixbase_seatcategorymapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_seatcategorymapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_seatingplan`
--

DROP TABLE IF EXISTS `pretixbase_seatingplan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_seatingplan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(190) NOT NULL,
  `layout` longtext NOT NULL,
  `organizer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_seatingpl_organizer_id_373881ef_fk_pretixbas` (`organizer_id`),
  CONSTRAINT `pretixbase_seatingpl_organizer_id_373881ef_fk_pretixbas` FOREIGN KEY (`organizer_id`) REFERENCES `pretixbase_organizer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_seatingplan`
--

LOCK TABLES `pretixbase_seatingplan` WRITE;
/*!40000 ALTER TABLE `pretixbase_seatingplan` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_seatingplan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_staffsession`
--

DROP TABLE IF EXISTS `pretixbase_staffsession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_staffsession` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` datetime(6) NOT NULL,
  `date_end` datetime(6) DEFAULT NULL,
  `session_key` varchar(255) NOT NULL,
  `comment` longtext NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_staffsession_user_id_dbe96c7a_fk_pretixbase_user_id` (`user_id`),
  CONSTRAINT `pretixbase_staffsession_user_id_dbe96c7a_fk_pretixbase_user_id` FOREIGN KEY (`user_id`) REFERENCES `pretixbase_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_staffsession`
--

LOCK TABLES `pretixbase_staffsession` WRITE;
/*!40000 ALTER TABLE `pretixbase_staffsession` DISABLE KEYS */;
INSERT INTO `pretixbase_staffsession` VALUES (1,'2020-02-18 17:35:06.816725','2020-02-18 17:42:31.230951','juj1xk0szcaa412r76dtra7lhzcxm7dn','',1);
/*!40000 ALTER TABLE `pretixbase_staffsession` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_staffsessionauditlog`
--

DROP TABLE IF EXISTS `pretixbase_staffsessionauditlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_staffsessionauditlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime(6) NOT NULL,
  `url` varchar(255) NOT NULL,
  `session_id` int(11) NOT NULL,
  `impersonating_id` int(11) DEFAULT NULL,
  `method` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_staffsess_impersonating_id_7d7562e3_fk_pretixbas` (`impersonating_id`),
  KEY `pretixbase_staffsess_session_id_48ead8a1_fk_pretixbas` (`session_id`),
  CONSTRAINT `pretixbase_staffsess_impersonating_id_7d7562e3_fk_pretixbas` FOREIGN KEY (`impersonating_id`) REFERENCES `pretixbase_user` (`id`),
  CONSTRAINT `pretixbase_staffsess_session_id_48ead8a1_fk_pretixbas` FOREIGN KEY (`session_id`) REFERENCES `pretixbase_staffsession` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_staffsessionauditlog`
--

LOCK TABLES `pretixbase_staffsessionauditlog` WRITE;
/*!40000 ALTER TABLE `pretixbase_staffsessionauditlog` DISABLE KEYS */;
INSERT INTO `pretixbase_staffsessionauditlog` VALUES (1,'2020-02-18 17:35:06.970442','/control/organizers/',1,NULL,'GET'),(2,'2020-02-18 17:35:09.131327','/control/organizers/add',1,NULL,'GET'),(3,'2020-02-18 17:35:18.188885','/control/organizers/add',1,NULL,'POST'),(4,'2020-02-18 17:35:18.615879','/control/organizer/hoeringsportal/',1,NULL,'GET'),(5,'2020-02-18 17:35:22.828947','/control/organizer/hoeringsportal/teams',1,NULL,'GET'),(6,'2020-02-18 17:36:11.687587','/control/organizer/hoeringsportal/team/add',1,NULL,'GET'),(7,'2020-02-18 17:36:39.991629','/control/organizer/hoeringsportal/team/add',1,NULL,'POST'),(8,'2020-02-18 17:36:40.035755','/control/organizer/hoeringsportal/team/2/',1,NULL,'GET'),(9,'2020-02-18 17:37:06.919667','/control/organizer/hoeringsportal/team/2/',1,NULL,'POST'),(10,'2020-02-18 17:37:17.165650','/control/organizer/hoeringsportal/team/2/',1,NULL,'POST'),(11,'2020-02-18 17:37:17.668039','/control/organizer/hoeringsportal/team/2/',1,NULL,'GET'),(12,'2020-02-18 17:37:37.292696','/control/organizer/hoeringsportal/teams',1,NULL,'GET'),(13,'2020-02-18 17:38:28.923048','/control/nav/typeahead/',1,NULL,'GET'),(14,'2020-02-18 17:38:36.613468','/control/organizer/hoeringsportal/edit',1,NULL,'GET'),(15,'2020-02-18 17:38:36.978427','/control/pdf/editor/webfonts.css',1,NULL,'GET'),(16,'2020-02-18 17:38:39.126894','/control/nav/typeahead/',1,NULL,'GET'),(17,'2020-02-18 17:38:41.465475','/control/organizer/hoeringsportal/',1,NULL,'GET'),(18,'2020-02-18 17:38:41.713009','/control/organizer/hoeringsportal/',1,NULL,'GET'),(19,'2020-02-18 17:38:49.070544','/control/nav/typeahead/',1,NULL,'GET'),(20,'2020-02-18 17:38:50.014543','/control/',1,NULL,'GET'),(21,'2020-02-18 17:38:52.029247','/control/organizers/',1,NULL,'GET'),(22,'2020-02-18 17:39:00.405644','/control/organizer/hoeringsportal/',1,NULL,'GET'),(23,'2020-02-18 17:42:31.226343','/control/sudo/stop/',1,NULL,'GET');
/*!40000 ALTER TABLE `pretixbase_staffsessionauditlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_subevent`
--

DROP TABLE IF EXISTS `pretixbase_subevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_subevent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL,
  `name` longtext NOT NULL,
  `date_from` datetime(6) NOT NULL,
  `date_to` datetime(6) DEFAULT NULL,
  `date_admission` datetime(6) DEFAULT NULL,
  `presale_end` datetime(6) DEFAULT NULL,
  `presale_start` datetime(6) DEFAULT NULL,
  `location` longtext DEFAULT NULL,
  `event_id` int(11) NOT NULL,
  `frontpage_text` longtext DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL,
  `seating_plan_id` int(11) DEFAULT NULL,
  `geo_lat` double DEFAULT NULL,
  `geo_lon` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_subevent_event_id_3ca2e6c9_fk_pretixbase_event_id` (`event_id`),
  KEY `pretixbase_subevent_seating_plan_id_5720ab67_fk_pretixbas` (`seating_plan_id`),
  CONSTRAINT `pretixbase_subevent_event_id_3ca2e6c9_fk_pretixbase_event_id` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `pretixbase_subevent_seating_plan_id_5720ab67_fk_pretixbas` FOREIGN KEY (`seating_plan_id`) REFERENCES `pretixbase_seatingplan` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_subevent`
--

LOCK TABLES `pretixbase_subevent` WRITE;
/*!40000 ALTER TABLE `pretixbase_subevent` DISABLE KEYS */;
INSERT INTO `pretixbase_subevent` VALUES (1,1,'{\"da\": \"Skabelon (serie)\", \"en\": \"Template (series)\"}','2001-01-01 00:00:00.000000',NULL,NULL,NULL,NULL,'{}',3,NULL,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `pretixbase_subevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_subeventitem`
--

DROP TABLE IF EXISTS `pretixbase_subeventitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_subeventitem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` decimal(7,2) DEFAULT NULL,
  `item_id` int(11) NOT NULL,
  `subevent_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_subeventitem_item_id_87c1ba29_fk_pretixbase_item_id` (`item_id`),
  KEY `pretixbase_subeventi_subevent_id_2da8e314_fk_pretixbas` (`subevent_id`),
  CONSTRAINT `pretixbase_subeventi_subevent_id_2da8e314_fk_pretixbas` FOREIGN KEY (`subevent_id`) REFERENCES `pretixbase_subevent` (`id`),
  CONSTRAINT `pretixbase_subeventitem_item_id_87c1ba29_fk_pretixbase_item_id` FOREIGN KEY (`item_id`) REFERENCES `pretixbase_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_subeventitem`
--

LOCK TABLES `pretixbase_subeventitem` WRITE;
/*!40000 ALTER TABLE `pretixbase_subeventitem` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_subeventitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_subeventitemvariation`
--

DROP TABLE IF EXISTS `pretixbase_subeventitemvariation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_subeventitemvariation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` decimal(7,2) DEFAULT NULL,
  `subevent_id` int(11) NOT NULL,
  `variation_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_subeventi_subevent_id_9fc7911f_fk_pretixbas` (`subevent_id`),
  KEY `pretixbase_subeventi_variation_id_182b380a_fk_pretixbas` (`variation_id`),
  CONSTRAINT `pretixbase_subeventi_subevent_id_9fc7911f_fk_pretixbas` FOREIGN KEY (`subevent_id`) REFERENCES `pretixbase_subevent` (`id`),
  CONSTRAINT `pretixbase_subeventi_variation_id_182b380a_fk_pretixbas` FOREIGN KEY (`variation_id`) REFERENCES `pretixbase_itemvariation` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_subeventitemvariation`
--

LOCK TABLES `pretixbase_subeventitemvariation` WRITE;
/*!40000 ALTER TABLE `pretixbase_subeventitemvariation` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_subeventitemvariation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_subeventmetavalue`
--

DROP TABLE IF EXISTS `pretixbase_subeventmetavalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_subeventmetavalue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` longtext NOT NULL,
  `property_id` int(11) NOT NULL,
  `subevent_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_subeventmetav_subevent_id_property_id_429c6af5_uniq` (`subevent_id`,`property_id`),
  KEY `pretixbase_subeventm_property_id_bda97d56_fk_pretixbas` (`property_id`),
  CONSTRAINT `pretixbase_subeventm_property_id_bda97d56_fk_pretixbas` FOREIGN KEY (`property_id`) REFERENCES `pretixbase_eventmetaproperty` (`id`),
  CONSTRAINT `pretixbase_subeventm_subevent_id_b97a87d2_fk_pretixbas` FOREIGN KEY (`subevent_id`) REFERENCES `pretixbase_subevent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_subeventmetavalue`
--

LOCK TABLES `pretixbase_subeventmetavalue` WRITE;
/*!40000 ALTER TABLE `pretixbase_subeventmetavalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_subeventmetavalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_taxrule`
--

DROP TABLE IF EXISTS `pretixbase_taxrule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_taxrule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `price_includes_tax` tinyint(1) NOT NULL,
  `eu_reverse_charge` tinyint(1) NOT NULL,
  `home_country` varchar(2) NOT NULL,
  `event_id` int(11) NOT NULL,
  `custom_rules` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_taxrule_event_id_178a74ee_fk_pretixbase_event_id` (`event_id`),
  CONSTRAINT `pretixbase_taxrule_event_id_178a74ee_fk_pretixbase_event_id` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_taxrule`
--

LOCK TABLES `pretixbase_taxrule` WRITE;
/*!40000 ALTER TABLE `pretixbase_taxrule` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_taxrule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_team`
--

DROP TABLE IF EXISTS `pretixbase_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(190) NOT NULL,
  `all_events` tinyint(1) NOT NULL,
  `can_create_events` tinyint(1) NOT NULL,
  `can_change_teams` tinyint(1) NOT NULL,
  `can_change_organizer_settings` tinyint(1) NOT NULL,
  `can_change_event_settings` tinyint(1) NOT NULL,
  `can_change_items` tinyint(1) NOT NULL,
  `can_view_orders` tinyint(1) NOT NULL,
  `can_change_orders` tinyint(1) NOT NULL,
  `can_view_vouchers` tinyint(1) NOT NULL,
  `can_change_vouchers` tinyint(1) NOT NULL,
  `organizer_id` int(11) NOT NULL,
  `can_manage_gift_cards` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_team_organizer_id_05a40a53_fk_pretixbase_organizer_id` (`organizer_id`),
  CONSTRAINT `pretixbase_team_organizer_id_05a40a53_fk_pretixbase_organizer_id` FOREIGN KEY (`organizer_id`) REFERENCES `pretixbase_organizer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_team`
--

LOCK TABLES `pretixbase_team` WRITE;
/*!40000 ALTER TABLE `pretixbase_team` DISABLE KEYS */;
INSERT INTO `pretixbase_team` VALUES (1,'Administrators',1,1,1,1,1,1,1,1,1,1,1,1),(2,'hoeringsportal',1,1,1,1,1,1,1,0,0,0,1,0);
/*!40000 ALTER TABLE `pretixbase_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_team_limit_events`
--

DROP TABLE IF EXISTS `pretixbase_team_limit_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_team_limit_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_team_limit_events_team_id_event_id_dc3aa150_uniq` (`team_id`,`event_id`),
  KEY `pretixbase_team_limi_event_id_f667e127_fk_pretixbas` (`event_id`),
  CONSTRAINT `pretixbase_team_limi_event_id_f667e127_fk_pretixbas` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `pretixbase_team_limi_team_id_0612e133_fk_pretixbas` FOREIGN KEY (`team_id`) REFERENCES `pretixbase_team` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_team_limit_events`
--

LOCK TABLES `pretixbase_team_limit_events` WRITE;
/*!40000 ALTER TABLE `pretixbase_team_limit_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_team_limit_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_team_members`
--

DROP TABLE IF EXISTS `pretixbase_team_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_team_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_team_members_team_id_user_id_c5b180ca_uniq` (`team_id`,`user_id`),
  KEY `pretixbase_team_members_user_id_ee9124e2_fk_pretixbase_user_id` (`user_id`),
  CONSTRAINT `pretixbase_team_members_team_id_9136ddb5_fk_pretixbase_team_id` FOREIGN KEY (`team_id`) REFERENCES `pretixbase_team` (`id`),
  CONSTRAINT `pretixbase_team_members_user_id_ee9124e2_fk_pretixbase_user_id` FOREIGN KEY (`user_id`) REFERENCES `pretixbase_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_team_members`
--

LOCK TABLES `pretixbase_team_members` WRITE;
/*!40000 ALTER TABLE `pretixbase_team_members` DISABLE KEYS */;
INSERT INTO `pretixbase_team_members` VALUES (1,1,1),(2,2,1);
/*!40000 ALTER TABLE `pretixbase_team_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_teamapitoken`
--

DROP TABLE IF EXISTS `pretixbase_teamapitoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_teamapitoken` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(190) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `token` varchar(64) NOT NULL,
  `team_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_teamapitoken_team_id_7c6c0b4b_fk_pretixbase_team_id` (`team_id`),
  CONSTRAINT `pretixbase_teamapitoken_team_id_7c6c0b4b_fk_pretixbase_team_id` FOREIGN KEY (`team_id`) REFERENCES `pretixbase_team` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_teamapitoken`
--

LOCK TABLES `pretixbase_teamapitoken` WRITE;
/*!40000 ALTER TABLE `pretixbase_teamapitoken` DISABLE KEYS */;
INSERT INTO `pretixbase_teamapitoken` VALUES (1,'hoeringsportal',1,'v84pb9f19gv5gkn2d8vbxoih6egx2v00hpbcwzwzqoqqixt22locej5rffmou78e',2);
/*!40000 ALTER TABLE `pretixbase_teamapitoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_teaminvite`
--

DROP TABLE IF EXISTS `pretixbase_teaminvite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_teaminvite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(254) DEFAULT NULL,
  `token` varchar(64) DEFAULT NULL,
  `team_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_teaminvite_team_id_bfe11558_fk_pretixbase_team_id` (`team_id`),
  CONSTRAINT `pretixbase_teaminvite_team_id_bfe11558_fk_pretixbase_team_id` FOREIGN KEY (`team_id`) REFERENCES `pretixbase_team` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_teaminvite`
--

LOCK TABLES `pretixbase_teaminvite` WRITE;
/*!40000 ALTER TABLE `pretixbase_teaminvite` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_teaminvite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_u2fdevice`
--

DROP TABLE IF EXISTS `pretixbase_u2fdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_u2fdevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `confirmed` tinyint(1) NOT NULL,
  `json_data` longtext NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_u2fdevice_user_id_83ffb7c2_fk_pretixbase_user_id` (`user_id`),
  CONSTRAINT `pretixbase_u2fdevice_user_id_83ffb7c2_fk_pretixbase_user_id` FOREIGN KEY (`user_id`) REFERENCES `pretixbase_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_u2fdevice`
--

LOCK TABLES `pretixbase_u2fdevice` WRITE;
/*!40000 ALTER TABLE `pretixbase_u2fdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_u2fdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_user`
--

DROP TABLE IF EXISTS `pretixbase_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `locale` varchar(50) NOT NULL,
  `timezone` varchar(100) NOT NULL,
  `require_2fa` tinyint(1) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `notifications_send` tinyint(1) NOT NULL,
  `notifications_token` varchar(255) NOT NULL,
  `auth_backend` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_user`
--

LOCK TABLES `pretixbase_user` WRITE;
/*!40000 ALTER TABLE `pretixbase_user` DISABLE KEYS */;
INSERT INTO `pretixbase_user` VALUES (1,'pbkdf2_sha256$150000$VSFmhm3zcrm6$XfAEr7hqFQfdyLRaCgP9TvISgaMoJeZiF84+HUrmt0Q=','2020-02-26 08:34:41.721361','admin@localhost',1,1,'2020-02-17 20:19:25.697751','en','UTC',0,NULL,1,'cEnQu4hHlgqIgwOxU3zX5k3ZycmouPfm','native');
/*!40000 ALTER TABLE `pretixbase_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_user_groups`
--

DROP TABLE IF EXISTS `pretixbase_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_user_groups_user_id_group_id_5129cb6b_uniq` (`user_id`,`group_id`),
  KEY `pretixbase_user_groups_group_id_98f0aee4_fk_auth_group_id` (`group_id`),
  CONSTRAINT `pretixbase_user_groups_group_id_98f0aee4_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `pretixbase_user_groups_user_id_844303d2_fk_pretixbase_user_id` FOREIGN KEY (`user_id`) REFERENCES `pretixbase_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_user_groups`
--

LOCK TABLES `pretixbase_user_groups` WRITE;
/*!40000 ALTER TABLE `pretixbase_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_user_user_permissions`
--

DROP TABLE IF EXISTS `pretixbase_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_user_user_per_user_id_permission_id_3bd15a95_uniq` (`user_id`,`permission_id`),
  KEY `pretixbase_user_user_permission_id_dfd420d0_fk_auth_perm` (`permission_id`),
  CONSTRAINT `pretixbase_user_user_permission_id_dfd420d0_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `pretixbase_user_user_user_id_a8c52ecb_fk_pretixbas` FOREIGN KEY (`user_id`) REFERENCES `pretixbase_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_user_user_permissions`
--

LOCK TABLES `pretixbase_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `pretixbase_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_voucher`
--

DROP TABLE IF EXISTS `pretixbase_voucher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `valid_until` datetime(6) DEFAULT NULL,
  `block_quota` tinyint(1) NOT NULL,
  `allow_ignore_quota` tinyint(1) NOT NULL,
  `value` decimal(10,2) DEFAULT NULL,
  `event_id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `redeemed` int(10) unsigned NOT NULL,
  `variation_id` int(11) DEFAULT NULL,
  `quota_id` int(11) DEFAULT NULL,
  `comment` longtext NOT NULL,
  `tag` varchar(255) NOT NULL,
  `max_usages` int(10) unsigned NOT NULL,
  `price_mode` varchar(100) NOT NULL,
  `subevent_id` int(11) DEFAULT NULL,
  `show_hidden_items` tinyint(1) NOT NULL,
  `seat_id` int(11) DEFAULT NULL,
  `budget` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixbase_voucher_event_id_code_b07c351f_uniq` (`event_id`,`code`),
  KEY `pretixbase_voucher_code_6691a85b` (`code`),
  KEY `pretixbase_voucher_tag_e3f384bf` (`tag`),
  KEY `pretixbase_voucher_valid_until_774d1851` (`valid_until`),
  KEY `pretixbase_voucher_subevent_id_dbc0b6a2_fk_pretixbas` (`subevent_id`),
  KEY `pretixbase_voucher_item_id_7082505d_fk_pretixbase_item_id` (`item_id`),
  KEY `pretixbase_voucher_quota_id_f1a35cde_fk_pretixbase_quota_id` (`quota_id`),
  KEY `pretixbase_voucher_variation_id_8b959226_fk_pretixbas` (`variation_id`),
  KEY `pretixbase_voucher_seat_id_b7906d99_fk_pretixbase_seat_id` (`seat_id`),
  CONSTRAINT `pretixbase_voucher_event_id_1bd19b72_fk_pretixbase_event_id` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `pretixbase_voucher_item_id_7082505d_fk_pretixbase_item_id` FOREIGN KEY (`item_id`) REFERENCES `pretixbase_item` (`id`),
  CONSTRAINT `pretixbase_voucher_quota_id_f1a35cde_fk_pretixbase_quota_id` FOREIGN KEY (`quota_id`) REFERENCES `pretixbase_quota` (`id`),
  CONSTRAINT `pretixbase_voucher_seat_id_b7906d99_fk_pretixbase_seat_id` FOREIGN KEY (`seat_id`) REFERENCES `pretixbase_seat` (`id`),
  CONSTRAINT `pretixbase_voucher_subevent_id_dbc0b6a2_fk_pretixbas` FOREIGN KEY (`subevent_id`) REFERENCES `pretixbase_subevent` (`id`),
  CONSTRAINT `pretixbase_voucher_variation_id_8b959226_fk_pretixbas` FOREIGN KEY (`variation_id`) REFERENCES `pretixbase_itemvariation` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_voucher`
--

LOCK TABLES `pretixbase_voucher` WRITE;
/*!40000 ALTER TABLE `pretixbase_voucher` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_voucher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_waitinglistentry`
--

DROP TABLE IF EXISTS `pretixbase_waitinglistentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_waitinglistentry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` datetime(6) NOT NULL,
  `email` varchar(254) NOT NULL,
  `locale` varchar(190) NOT NULL,
  `event_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `variation_id` int(11) DEFAULT NULL,
  `voucher_id` int(11) DEFAULT NULL,
  `subevent_id` int(11) DEFAULT NULL,
  `priority` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_waitingli_event_id_f29b59b0_fk_pretixbas` (`event_id`),
  KEY `pretixbase_waitingli_item_id_3f39aada_fk_pretixbas` (`item_id`),
  KEY `pretixbase_waitingli_variation_id_8f59d1c1_fk_pretixbas` (`variation_id`),
  KEY `pretixbase_waitingli_subevent_id_8bda61c7_fk_pretixbas` (`subevent_id`),
  KEY `pretixbase_waitingli_voucher_id_109e4555_fk_pretixbas` (`voucher_id`),
  CONSTRAINT `pretixbase_waitingli_event_id_f29b59b0_fk_pretixbas` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `pretixbase_waitingli_item_id_3f39aada_fk_pretixbas` FOREIGN KEY (`item_id`) REFERENCES `pretixbase_item` (`id`),
  CONSTRAINT `pretixbase_waitingli_subevent_id_8bda61c7_fk_pretixbas` FOREIGN KEY (`subevent_id`) REFERENCES `pretixbase_subevent` (`id`),
  CONSTRAINT `pretixbase_waitingli_variation_id_8f59d1c1_fk_pretixbas` FOREIGN KEY (`variation_id`) REFERENCES `pretixbase_itemvariation` (`id`),
  CONSTRAINT `pretixbase_waitingli_voucher_id_109e4555_fk_pretixbas` FOREIGN KEY (`voucher_id`) REFERENCES `pretixbase_voucher` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_waitinglistentry`
--

LOCK TABLES `pretixbase_waitinglistentry` WRITE;
/*!40000 ALTER TABLE `pretixbase_waitinglistentry` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_waitinglistentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixbase_webauthndevice`
--

DROP TABLE IF EXISTS `pretixbase_webauthndevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixbase_webauthndevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `confirmed` tinyint(1) NOT NULL,
  `credential_id` varchar(255) DEFAULT NULL,
  `rp_id` varchar(255) DEFAULT NULL,
  `icon_url` varchar(255) DEFAULT NULL,
  `ukey` longtext DEFAULT NULL,
  `pub_key` longtext DEFAULT NULL,
  `sign_count` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixbase_webauthndevice_user_id_7fbd58ca_fk_pretixbase_user_id` (`user_id`),
  CONSTRAINT `pretixbase_webauthndevice_user_id_7fbd58ca_fk_pretixbase_user_id` FOREIGN KEY (`user_id`) REFERENCES `pretixbase_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixbase_webauthndevice`
--

LOCK TABLES `pretixbase_webauthndevice` WRITE;
/*!40000 ALTER TABLE `pretixbase_webauthndevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixbase_webauthndevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixdroid_appconfiguration`
--

DROP TABLE IF EXISTS `pretixdroid_appconfiguration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixdroid_appconfiguration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(190) NOT NULL,
  `all_items` tinyint(1) NOT NULL,
  `allow_search` tinyint(1) NOT NULL,
  `show_info` tinyint(1) NOT NULL,
  `event_id` int(11) NOT NULL,
  `list_id` int(11) NOT NULL,
  `app` varchar(190) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pretixdroid_appconfi_event_id_af2e7ba6_fk_pretixbas` (`event_id`),
  KEY `pretixdroid_appconfiguration_key_dbf0df43` (`key`),
  KEY `pretixdroid_appconfi_list_id_aaeb22aa_fk_pretixbas` (`list_id`),
  CONSTRAINT `pretixdroid_appconfi_event_id_af2e7ba6_fk_pretixbas` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`),
  CONSTRAINT `pretixdroid_appconfi_list_id_aaeb22aa_fk_pretixbas` FOREIGN KEY (`list_id`) REFERENCES `pretixbase_checkinlist` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixdroid_appconfiguration`
--

LOCK TABLES `pretixdroid_appconfiguration` WRITE;
/*!40000 ALTER TABLE `pretixdroid_appconfiguration` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixdroid_appconfiguration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixdroid_appconfiguration_items`
--

DROP TABLE IF EXISTS `pretixdroid_appconfiguration_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixdroid_appconfiguration_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appconfiguration_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixdroid_appconfigura_appconfiguration_id_item_59969331_uniq` (`appconfiguration_id`,`item_id`),
  KEY `pretixdroid_appconfi_item_id_f7db6bdb_fk_pretixbas` (`item_id`),
  CONSTRAINT `pretixdroid_appconfi_appconfiguration_id_ea02f8b8_fk_pretixdro` FOREIGN KEY (`appconfiguration_id`) REFERENCES `pretixdroid_appconfiguration` (`id`),
  CONSTRAINT `pretixdroid_appconfi_item_id_f7db6bdb_fk_pretixbas` FOREIGN KEY (`item_id`) REFERENCES `pretixbase_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixdroid_appconfiguration_items`
--

LOCK TABLES `pretixdroid_appconfiguration_items` WRITE;
/*!40000 ALTER TABLE `pretixdroid_appconfiguration_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixdroid_appconfiguration_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixhelpers_thumbnail`
--

DROP TABLE IF EXISTS `pretixhelpers_thumbnail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixhelpers_thumbnail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source` varchar(255) NOT NULL,
  `size` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pretixhelpers_thumbnail_source_size_52961027_uniq` (`source`,`size`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixhelpers_thumbnail`
--

LOCK TABLES `pretixhelpers_thumbnail` WRITE;
/*!40000 ALTER TABLE `pretixhelpers_thumbnail` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixhelpers_thumbnail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pretixmultidomain_knowndomain`
--

DROP TABLE IF EXISTS `pretixmultidomain_knowndomain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pretixmultidomain_knowndomain` (
  `domainname` varchar(255) NOT NULL,
  `organizer_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`domainname`),
  KEY `pretixmultidomain_kn_organizer_id_2d571a7f_fk_pretixbas` (`organizer_id`),
  CONSTRAINT `pretixmultidomain_kn_organizer_id_2d571a7f_fk_pretixbas` FOREIGN KEY (`organizer_id`) REFERENCES `pretixbase_organizer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pretixmultidomain_knowndomain`
--

LOCK TABLES `pretixmultidomain_knowndomain` WRITE;
/*!40000 ALTER TABLE `pretixmultidomain_knowndomain` DISABLE KEYS */;
/*!40000 ALTER TABLE `pretixmultidomain_knowndomain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stripe_referencedstripeobject`
--

DROP TABLE IF EXISTS `stripe_referencedstripeobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stripe_referencedstripeobject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(190) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `stripe_referencedstr_order_id_c9c61aeb_fk_pretixbas` (`order_id`),
  KEY `stripe_referencedstr_payment_id_51b1ab47_fk_pretixbas` (`payment_id`),
  CONSTRAINT `stripe_referencedstr_order_id_c9c61aeb_fk_pretixbas` FOREIGN KEY (`order_id`) REFERENCES `pretixbase_order` (`id`),
  CONSTRAINT `stripe_referencedstr_payment_id_51b1ab47_fk_pretixbas` FOREIGN KEY (`payment_id`) REFERENCES `pretixbase_orderpayment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stripe_referencedstripeobject`
--

LOCK TABLES `stripe_referencedstripeobject` WRITE;
/*!40000 ALTER TABLE `stripe_referencedstripeobject` DISABLE KEYS */;
/*!40000 ALTER TABLE `stripe_referencedstripeobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stripe_registeredapplepaydomain`
--

DROP TABLE IF EXISTS `stripe_registeredapplepaydomain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stripe_registeredapplepaydomain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(190) NOT NULL,
  `account` varchar(190) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stripe_registeredapplepaydomain`
--

LOCK TABLES `stripe_registeredapplepaydomain` WRITE;
/*!40000 ALTER TABLE `stripe_registeredapplepaydomain` DISABLE KEYS */;
/*!40000 ALTER TABLE `stripe_registeredapplepaydomain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticketoutputpdf_ticketlayout`
--

DROP TABLE IF EXISTS `ticketoutputpdf_ticketlayout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticketoutputpdf_ticketlayout` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `default` tinyint(1) NOT NULL,
  `name` varchar(190) NOT NULL,
  `layout` longtext NOT NULL,
  `background` varchar(255) DEFAULT NULL,
  `event_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ticketoutputpdf_tick_event_id_7119c6d2_fk_pretixbas` (`event_id`),
  CONSTRAINT `ticketoutputpdf_tick_event_id_7119c6d2_fk_pretixbas` FOREIGN KEY (`event_id`) REFERENCES `pretixbase_event` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticketoutputpdf_ticketlayout`
--

LOCK TABLES `ticketoutputpdf_ticketlayout` WRITE;
/*!40000 ALTER TABLE `ticketoutputpdf_ticketlayout` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticketoutputpdf_ticketlayout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticketoutputpdf_ticketlayoutitem`
--

DROP TABLE IF EXISTS `ticketoutputpdf_ticketlayoutitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticketoutputpdf_ticketlayoutitem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) DEFAULT NULL,
  `layout_id` int(11) NOT NULL,
  `sales_channel` varchar(190) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticketoutputpdf_ticketla_item_id_layout_id_sales__41990928_uniq` (`item_id`,`layout_id`,`sales_channel`),
  KEY `ticketoutputpdf_tick_layout_id_9b76e49f_fk_ticketout` (`layout_id`),
  KEY `ticketoutputpdf_ticketlayoutitem_item_id_273d9107` (`item_id`),
  CONSTRAINT `ticketoutputpdf_tick_item_id_273d9107_fk_pretixbas` FOREIGN KEY (`item_id`) REFERENCES `pretixbase_item` (`id`),
  CONSTRAINT `ticketoutputpdf_tick_layout_id_9b76e49f_fk_ticketout` FOREIGN KEY (`layout_id`) REFERENCES `ticketoutputpdf_ticketlayout` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticketoutputpdf_ticketlayoutitem`
--

LOCK TABLES `ticketoutputpdf_ticketlayoutitem` WRITE;
/*!40000 ALTER TABLE `ticketoutputpdf_ticketlayoutitem` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticketoutputpdf_ticketlayoutitem` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-26  9:45:30
